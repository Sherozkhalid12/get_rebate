import 'package:get/get.dart';

class HelpSupportController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }
}




