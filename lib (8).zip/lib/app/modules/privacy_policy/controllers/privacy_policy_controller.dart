import 'package:get/get.dart';

class PrivacyPolicyController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }
}




