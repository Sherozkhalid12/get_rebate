import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/controllers/auth_controller.dart' as global;
import 'package:getrebate/app/models/user_model.dart';

class AuthViewController extends GetxController {
  final global.AuthController _globalAuthController =
      Get.find<global.AuthController>();

  // Form controllers
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final phoneController = TextEditingController();

  // Observable variables
  final _isLoginMode = true.obs;
  final _selectedRole = UserRole.buyerSeller.obs;
  final _isLoading = false.obs;
  final _obscurePassword = true.obs;
  final Rxn<bool> _isDualAgencyAllowedInState = Rxn<bool>();
  final Rxn<bool> _isDualAgencyAllowedAtBrokerage = Rxn<bool>();

  // Getters
  bool get isLoginMode => _isLoginMode.value;
  UserRole get selectedRole => _selectedRole.value;
  bool get isLoading => _isLoading.value;
  bool get obscurePassword => _obscurePassword.value;
  bool? get isDualAgencyAllowedInState => _isDualAgencyAllowedInState.value;
  bool? get isDualAgencyAllowedAtBrokerage =>
      _isDualAgencyAllowedAtBrokerage.value;

  void toggleMode() {
    _isLoginMode.value = !_isLoginMode.value;
    _clearForm();
  }

  void togglePasswordVisibility() {
    _obscurePassword.value = !_obscurePassword.value;
  }

  void selectRole(UserRole role) {
    _selectedRole.value = role;
    // Reset dual agency fields when changing roles
    _isDualAgencyAllowedInState.value = null;
    _isDualAgencyAllowedAtBrokerage.value = null;
  }

  void setDualAgencyInState(bool? value) {
    _isDualAgencyAllowedInState.value = value;
  }

  void setDualAgencyAtBrokerage(bool? value) {
    _isDualAgencyAllowedAtBrokerage.value = value;
  }

  void _clearForm() {
    emailController.clear();
    passwordController.clear();
    nameController.clear();
    phoneController.clear();
    _isDualAgencyAllowedInState.value = null;
    _isDualAgencyAllowedAtBrokerage.value = null;
  }

  Future<void> submitForm() async {
    if (!_validateForm()) return;

    try {
      _isLoading.value = true;

      if (isLoginMode) {
        await _globalAuthController.login(
          email: emailController.text.trim(),
          password: passwordController.text,
        );
      } else {
        // Prepare additional data for agents
        Map<String, dynamic>? additionalData;
        if (selectedRole == UserRole.agent) {
          additionalData = {
            'isDualAgencyAllowedInState': isDualAgencyAllowedInState,
            'isDualAgencyAllowedAtBrokerage': isDualAgencyAllowedAtBrokerage,
          };
        }

        await _globalAuthController.signUp(
          email: emailController.text.trim(),
          password: passwordController.text,
          name: nameController.text.trim(),
          role: selectedRole,
          phone: phoneController.text.trim().isNotEmpty
              ? phoneController.text.trim()
              : null,
          licensedStates:
              selectedRole == UserRole.agent ||
                  selectedRole == UserRole.loanOfficer
              ? ['NY', 'CA'] // Default states for demo
              : null,
          additionalData: additionalData,
        );
      }
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> socialLogin(String provider) async {
    try {
      _isLoading.value = true;

      // Mock social login data
      final mockData = {
        'google': {
          'email': 'user@gmail.com',
          'name': 'Google User',
          'profileImage': null,
        },
        'apple': {
          'email': 'user@icloud.com',
          'name': 'Apple User',
          'profileImage': null,
        },
        'facebook': {
          'email': 'user@facebook.com',
          'name': 'Facebook User',
          'profileImage': null,
        },
      };

      final data = mockData[provider];
      if (data != null) {
        await _globalAuthController.socialLogin(
          provider: provider,
          email: data['email']!,
          name: data['name']!,
          profileImage: data['profileImage'],
        );
      }
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      _isLoading.value = false;
    }
  }

  bool _validateForm() {
    if (emailController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter your email');
      return false;
    }

    if (!GetUtils.isEmail(emailController.text.trim())) {
      Get.snackbar('Error', 'Please enter a valid email');
      return false;
    }

    if (passwordController.text.isEmpty) {
      Get.snackbar('Error', 'Please enter your password');
      return false;
    }

    if (passwordController.text.length < 6) {
      Get.snackbar('Error', 'Password must be at least 6 characters');
      return false;
    }

    if (!isLoginMode) {
      if (nameController.text.trim().isEmpty) {
        Get.snackbar('Error', 'Please enter your name');
        return false;
      }

      // Validate dual agency questions for agents
      if (selectedRole == UserRole.agent) {
        if (isDualAgencyAllowedInState == null) {
          Get.snackbar(
            'Error',
            'Please answer if dual agency is allowed in your state',
          );
          return false;
        }
        if (isDualAgencyAllowedAtBrokerage == null) {
          Get.snackbar(
            'Error',
            'Please answer if dual agency is allowed at your brokerage',
          );
          return false;
        }
      }
    }

    return true;
  }

  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    phoneController.dispose();
    super.onClose();
  }
}
