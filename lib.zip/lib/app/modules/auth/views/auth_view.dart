import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:getrebate/app/theme/app_theme.dart';
import 'package:getrebate/app/modules/auth/controllers/auth_controller.dart';
import 'package:getrebate/app/widgets/custom_button.dart';
import 'package:getrebate/app/widgets/custom_text_field.dart';
import 'package:getrebate/app/models/user_model.dart';

class AuthView extends GetView<AuthViewController> {
  const AuthView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),

              // Header
              _buildHeader(context),

              const SizedBox(height: 40),

              // Form
              _buildForm(context),

              const SizedBox(height: 32),

              // Social login
              _buildSocialLogin(context),

              const SizedBox(height: 24),

              // Toggle mode
              _buildToggleMode(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Column(
      children: [
        // Logo
        Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: AppTheme.primaryBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.home_work,
                size: 40,
                color: AppTheme.primaryBlue,
              ),
            )
            .animate()
            .scale(duration: 600.ms, curve: Curves.elasticOut)
            .fadeIn(duration: 800.ms),

        const SizedBox(height: 24),

        // Title
        Obx(
              () => Text(
                controller.isLoginMode ? 'Welcome Back' : 'Create Account',
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  color: AppTheme.black,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            )
            .animate()
            .slideY(
              begin: 0.3,
              duration: 800.ms,
              curve: Curves.easeOut,
              delay: 200.ms,
            )
            .fadeIn(duration: 800.ms, delay: 200.ms),

        const SizedBox(height: 8),

        // Subtitle
        Obx(
              () => Text(
                controller.isLoginMode
                    ? 'Sign in to continue to GetaRebate'
                    : 'Join GetaRebate and start saving on real estate',
                style: Theme.of(
                  context,
                ).textTheme.bodyLarge?.copyWith(color: AppTheme.mediumGray),
                textAlign: TextAlign.center,
              ),
            )
            .animate()
            .slideY(
              begin: 0.3,
              duration: 800.ms,
              curve: Curves.easeOut,
              delay: 400.ms,
            )
            .fadeIn(duration: 800.ms, delay: 400.ms),
      ],
    );
  }

  Widget _buildForm(BuildContext context) {
    return Obx(
      () => Column(
        children: [
          // Name field (only for signup)
          if (!controller.isLoginMode) ...[
            CustomTextField(
                  controller: controller.nameController,
                  labelText: 'Full Name',
                  prefixIcon: Icons.person_outline,
                )
                .animate()
                .slideX(begin: -0.3, duration: 600.ms, curve: Curves.easeOut)
                .fadeIn(duration: 600.ms),

            const SizedBox(height: 16),
          ],

          // Email field
          CustomTextField(
                controller: controller.emailController,
                labelText: 'Email',
                keyboardType: TextInputType.emailAddress,
                prefixIcon: Icons.email_outlined,
              )
              .animate()
              .slideX(
                begin: -0.3,
                duration: 600.ms,
                curve: Curves.easeOut,
                delay: controller.isLoginMode ? 0.ms : 100.ms,
              )
              .fadeIn(
                duration: 600.ms,
                delay: controller.isLoginMode ? 0.ms : 100.ms,
              ),

          const SizedBox(height: 16),

          // Password field
          CustomTextField(
                controller: controller.passwordController,
                labelText: 'Password',
                obscureText: controller.obscurePassword,
                prefixIcon: Icons.lock_outline,
                suffixIcon: IconButton(
                  icon: Icon(
                    controller.obscurePassword
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: AppTheme.mediumGray,
                  ),
                  onPressed: controller.togglePasswordVisibility,
                ),
              )
              .animate()
              .slideX(
                begin: -0.3,
                duration: 600.ms,
                curve: Curves.easeOut,
                delay: controller.isLoginMode ? 100.ms : 200.ms,
              )
              .fadeIn(
                duration: 600.ms,
                delay: controller.isLoginMode ? 100.ms : 200.ms,
              ),

          // Phone field (only for signup)
          if (!controller.isLoginMode) ...[
            const SizedBox(height: 16),
            CustomTextField(
                  controller: controller.phoneController,
                  labelText: 'Phone (Optional)',
                  keyboardType: TextInputType.phone,
                  prefixIcon: Icons.phone_outlined,
                )
                .animate()
                .slideX(
                  begin: -0.3,
                  duration: 600.ms,
                  curve: Curves.easeOut,
                  delay: 300.ms,
                )
                .fadeIn(duration: 600.ms, delay: 300.ms),
          ],

          // Dual Agency Questions (only for agent signup)
          if (!controller.isLoginMode &&
              controller.selectedRole == UserRole.agent) ...[
            const SizedBox(height: 24),
            _buildDualAgencyQuestions(context),
          ],

          // Role selection (only for signup)
          if (!controller.isLoginMode) ...[
            const SizedBox(height: 24),
            _buildRoleSelection(context),
          ],

          const SizedBox(height: 32),

          // Submit button
          Obx(
                () => CustomButton(
                  text: controller.isLoginMode ? 'Sign In' : 'Create Account',
                  onPressed: controller.isLoading
                      ? null
                      : controller.submitForm,
                  isLoading: controller.isLoading,
                  width: double.infinity,
                ),
              )
              .animate()
              .slideY(
                begin: 0.3,
                duration: 600.ms,
                curve: Curves.easeOut,
                delay: controller.isLoginMode ? 200.ms : 500.ms,
              )
              .fadeIn(
                duration: 600.ms,
                delay: controller.isLoginMode ? 200.ms : 500.ms,
              ),
        ],
      ),
    );
  }

  Widget _buildRoleSelection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Choose your role',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: AppTheme.darkGray,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        Obx(
          () => Row(
            children: [
              Expanded(
                child: _buildRoleCard(
                  context,
                  UserRole.buyerSeller,
                  'Buyer/Seller',
                  Icons.home,
                  'Looking to buy or sell a home',
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildRoleCard(
                  context,
                  UserRole.agent,
                  'Agent',
                  Icons.person,
                  'Real estate agent',
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Obx(
          () => Row(
            children: [
              Expanded(
                child: _buildRoleCard(
                  context,
                  UserRole.loanOfficer,
                  'Loan Officer',
                  Icons.account_balance,
                  'Mortgage professional',
                ),
              ),
              const SizedBox(width: 12),
              // Empty space to maintain layout
              const Expanded(child: SizedBox()),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRoleCard(
    BuildContext context,
    UserRole role,
    String title,
    IconData icon,
    String subtitle,
  ) {
    final isSelected = controller.selectedRole == role;

    return GestureDetector(
      onTap: () => controller.selectRole(role),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryBlue.withOpacity(0.1)
              : AppTheme.lightGray,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppTheme.primaryBlue : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected ? AppTheme.primaryBlue : AppTheme.mediumGray,
              size: 24,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: isSelected ? AppTheme.primaryBlue : AppTheme.darkGray,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: AppTheme.mediumGray),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDualAgencyQuestions(BuildContext context) {
    return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.lightGray,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppTheme.primaryBlue.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Dual Agency Information',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppTheme.darkGray,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Dual Agency happens when the buyer is working with an agent from the same Brokerage that has the property listed for sale.',
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(color: AppTheme.mediumGray),
              ),
              const SizedBox(height: 16),

              // Is Dual Agency Allowed in your State?
              Text(
                'Is Dual Agency Allowed in your State?',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.darkGray,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              Obx(
                () => Row(
                  children: [
                    Expanded(
                      child: _buildYesNoButton(
                        context,
                        'Yes',
                        controller.isDualAgencyAllowedInState == true,
                        () => controller.setDualAgencyInState(true),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildYesNoButton(
                        context,
                        'No',
                        controller.isDualAgencyAllowedInState == false,
                        () => controller.setDualAgencyInState(false),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Is Dual Agency Allowed at your Brokerage?
              Text(
                'Is Dual Agency Allowed at your Brokerage?',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.darkGray,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 8),
              Obx(
                () => Row(
                  children: [
                    Expanded(
                      child: _buildYesNoButton(
                        context,
                        'Yes',
                        controller.isDualAgencyAllowedAtBrokerage == true,
                        () => controller.setDualAgencyAtBrokerage(true),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildYesNoButton(
                        context,
                        'No',
                        controller.isDualAgencyAllowedAtBrokerage == false,
                        () => controller.setDualAgencyAtBrokerage(false),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        .animate()
        .slideY(
          begin: 0.3,
          duration: 600.ms,
          curve: Curves.easeOut,
          delay: 400.ms,
        )
        .fadeIn(duration: 600.ms, delay: 400.ms);
  }

  Widget _buildYesNoButton(
    BuildContext context,
    String text,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryBlue : AppTheme.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected ? AppTheme.primaryBlue : AppTheme.mediumGray,
            width: 1.5,
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: isSelected ? AppTheme.white : AppTheme.darkGray,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialLogin(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const Expanded(child: Divider(color: AppTheme.mediumGray)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Or continue with',
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(color: AppTheme.mediumGray),
              ),
            ),
            const Expanded(child: Divider(color: AppTheme.mediumGray)),
          ],
        ),

        const SizedBox(height: 24),

        Row(
          children: [
            Expanded(
              child: CustomIconButton(
                icon: Icons.g_mobiledata,
                onPressed: () => controller.socialLogin('google'),
                backgroundColor: AppTheme.lightGray,
                iconColor: AppTheme.darkGray,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: CustomIconButton(
                icon: Icons.apple,
                onPressed: () => controller.socialLogin('apple'),
                backgroundColor: AppTheme.black,
                iconColor: AppTheme.white,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: CustomIconButton(
                icon: Icons.facebook,
                onPressed: () => controller.socialLogin('facebook'),
                backgroundColor: const Color(0xFF1877F2),
                iconColor: AppTheme.white,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildToggleMode(BuildContext context) {
    return Obx(
      () => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            controller.isLoginMode
                ? "Don't have an account? "
                : "Already have an account? ",
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(color: AppTheme.mediumGray),
          ),
          GestureDetector(
            onTap: controller.toggleMode,
            child: Text(
              controller.isLoginMode ? 'Sign Up' : 'Sign In',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppTheme.primaryBlue,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
