import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/theme/app_theme.dart';
import 'package:getrebate/app/modules/property_detail/controllers/property_detail_controller.dart';
import 'package:getrebate/app/widgets/custom_button.dart';
import 'package:getrebate/app/widgets/rebate_display_widget.dart';
import 'package:getrebate/app/widgets/nearby_agents_widget.dart';
import 'package:getrebate/app/models/listing.dart';

class PropertyDetailView extends GetView<PropertyDetailController> {
  const PropertyDetailView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: CustomScrollView(
        slivers: [
          // App Bar with Image
          _buildSliverAppBar(context),

          // Property Details
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Property Info
                  _buildPropertyInfo(context),

                  const SizedBox(height: 24),

                  // Property Features
                  _buildPropertyFeatures(context),

                  const SizedBox(height: 24),

                  // Agent Info
                  _buildAgentInfo(context),

                  const SizedBox(height: 24),

                  // Rebate Information
                  _buildRebateInfo(context),

                  const SizedBox(height: 24),

                  // Action Buttons
                  _buildActionButtons(context),

                  const SizedBox(height: 24),

                  // Property Description
                  _buildPropertyDescription(context),

                  const SizedBox(height: 100), // Bottom padding
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar(BuildContext context) {
    final images =
        controller.property['images'] ?? [controller.property['image']];

    return SliverAppBar(
      expandedHeight: 300,
      pinned: true,
      backgroundColor: AppTheme.primaryBlue,
      leading: IconButton(
        onPressed: () => Get.back(),
        icon: const Icon(Icons.arrow_back, color: AppTheme.white),
      ),
      actions: [
        Obx(
          () => IconButton(
            onPressed: controller.toggleFavorite,
            icon: Icon(
              controller.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: controller.isFavorite ? Colors.red : AppTheme.white,
            ),
          ),
        ),
        IconButton(
          onPressed: () {
            // TODO: Implement share functionality
            Get.snackbar('Share', 'Share functionality coming soon!');
          },
          icon: const Icon(Icons.share, color: AppTheme.white),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: AppTheme.primaryGradient,
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Property Image
              PageView.builder(
                onPageChanged: controller.setCurrentImageIndex,
                itemCount: images.length,
                itemBuilder: (context, index) {
                  return Image.network(
                    images[index],
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: AppTheme.lightGray,
                        child: const Icon(
                          Icons.home,
                          size: 48,
                          color: AppTheme.mediumGray,
                        ),
                      );
                    },
                  );
                },
              ),

              // Gradient overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withOpacity(0.3)],
                  ),
                ),
              ),

              // Image indicators
              if (images.length > 1)
                Positioned(
                  bottom: 16,
                  left: 0,
                  right: 0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      images.length,
                      (index) => Obx(
                        () => Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: controller.currentImageIndex == index
                                ? AppTheme.white
                                : AppTheme.white.withOpacity(0.5),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPropertyInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Price
        Text(
          controller.property['price'] ?? 'Price not available',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: AppTheme.primaryBlue,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 8),

        // Address
        Text(
          controller.property['address'] ?? 'Address not available',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            color: AppTheme.black,
            fontWeight: FontWeight.w600,
          ),
        ),

        const SizedBox(height: 8),

        // Status
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: (controller.property['status'] == 'For Sale')
                ? AppTheme.lightGreen.withOpacity(0.1)
                : AppTheme.mediumGray.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            controller.property['status'] ?? 'Status unknown',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: (controller.property['status'] == 'For Sale')
                  ? AppTheme.lightGreen
                  : AppTheme.mediumGray,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPropertyFeatures(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Property Features',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: AppTheme.black,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),

        Wrap(
          spacing: 16,
          runSpacing: 8,
          children: [
            _buildFeatureItem(
              context,
              Icons.bed,
              '${controller.property['beds'] ?? 'N/A'} beds',
            ),
            _buildFeatureItem(
              context,
              Icons.bathtub,
              '${controller.property['baths'] ?? 'N/A'} baths',
            ),
            _buildFeatureItem(
              context,
              Icons.square_foot,
              '${controller.property['sqft'] ?? 'N/A'} sqft',
            ),
          ],
        ),

        if (controller.property['lotSize'] != null) ...[
          const SizedBox(height: 16),
          _buildFeatureItem(
            context,
            Icons.landscape,
            '${controller.property['lotSize']} lot',
          ),
        ],

        if (controller.property['yearBuilt'] != null) ...[
          const SizedBox(height: 16),
          _buildFeatureItem(
            context,
            Icons.calendar_today,
            'Built ${controller.property['yearBuilt']}',
          ),
        ],
      ],
    );
  }

  Widget _buildFeatureItem(BuildContext context, IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.mediumGray, size: 20),
        const SizedBox(width: 8),
        Text(
          text,
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(color: AppTheme.darkGray),
        ),
      ],
    );
  }

  Widget _buildAgentInfo(BuildContext context) {
    final agent = controller.property['agent'] ?? {};

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.lightGray,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Listed by',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppTheme.black,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundImage: agent['profileImage'] != null
                    ? NetworkImage(agent['profileImage'])
                    : null,
                child: agent['profileImage'] == null
                    ? const Icon(Icons.person, color: AppTheme.white)
                    : null,
              ),
              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      agent['name'] ?? 'Agent Name',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      agent['company'] ?? 'Real Estate Company',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.mediumGray,
                      ),
                    ),
                  ],
                ),
              ),

              IconButton(
                onPressed: controller.contactAgent,
                icon: const Icon(Icons.message, color: AppTheme.primaryBlue),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRebateInfo(BuildContext context) {
    // Create a mock listing from property data for demonstration
    final property = controller.property;

    // Safely extract price value - handle both numeric and string formats
    double price;
    if (property['price'] is String) {
      // Remove currency formatting and convert to number
      final priceStr = property['price'].toString().replaceAll(
        RegExp(r'[^\d.]'),
        '',
      );
      price = double.tryParse(priceStr) ?? 400000;
    } else if (property['price'] is num) {
      price = property['price'].toDouble();
    } else {
      price = 400000; // Default fallback
    }

    final mockListing = Listing(
      id: property['id'] ?? 'mock_id',
      agentId: property['agentId'] ?? 'mock_agent_id',
      priceCents: (price * 100).toInt(),
      address: ListingAddress(
        street: property['address'] ?? '123 Park Avenue',
        city: property['city'] ?? 'New York',
        state: property['state'] ?? 'NY',
        zip: property['zip'] ?? '10001',
      ),
      photoUrls: List<String>.from(
        property['images'] ?? [property['image'] ?? ''],
      ),
      bacPercent:
          (property['bacPercent'] ?? 2.7) * 100, // Convert to percentage
      dualAgencyAllowed: property['dualAgencyAllowed'] ?? true,
      dualAgencyCommissionPercent:
          property['dualAgencyCommissionPercent'] != null
          ? (property['dualAgencyCommissionPercent'] as num).toDouble() * 100
          : (property['dualAgencyAllowed'] == true
                ? 400.0
                : null), // Default to 4% for dual agency
      createdAt: DateTime.now(),
    );

    return Column(
      children: [
        RebateDisplayWidget(
          listing: mockListing,
          onFindAgents: () => _showNearbyAgents(context, mockListing),
          onDualAgencyInfo: () => _showDualAgencyInfo(context),
        ),
        const SizedBox(height: 16),
        _buildRebateDisclosure(context),
        const SizedBox(height: 16),
        NearbyAgentsWidget(listing: mockListing),
      ],
    );
  }

  Widget _buildRebateDisclosure(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.primaryBlue.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: AppTheme.primaryBlue, size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Important Rebate Disclosure',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppTheme.primaryBlue,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              TextButton.icon(
                onPressed: () => _showFullRebateDisclosure(context),
                icon: Icon(Icons.open_in_full, size: 16),
                label: Text('View Full'),
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.primaryBlue,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'The Get a Rebate Real Estate platform is designed to help buyers and sellers save money by sharing a portion of the real estate commission earned by participating agents. The availability and amount of a rebate will vary based on the total commission received and applicable state laws.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppTheme.darkGray,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.amber.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.amber.shade200),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  color: Colors.amber.shade700,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Real estate commissions are 100% negotiable.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.amber.shade900,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 10),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.amber.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.amber.shade200),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  color: Colors.amber.shade700,
                  size: 20,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Commission rates and rebate percentages are subject tp negotiaiton and final agreement between all parties',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.amber.shade900,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showFullRebateDisclosure(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => RebateDisclosureDialog(
        onAcknowledge: () {
          controller.acknowledgeRebateDisclosure();
          Get.back();
        },
      ),
    );
  }

  void _showNearbyAgents(BuildContext context, Listing listing) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: const BoxDecoration(
          color: AppTheme.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: AppTheme.lightGray, width: 1),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Nearby Agents',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Get.back(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            Expanded(child: NearbyAgentsWidget(listing: listing)),
          ],
        ),
      ),
    );
  }

  void _showDualAgencyInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const DualAgencyExplanationDialog(),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Column(
      children: [
        // Primary action buttons
        Row(
          children: [
            Expanded(
              child: CustomButton(
                text: 'I am interested in this property',
                onPressed: controller.openBuyerLeadForm,
                fontSize: 11.sp,
                icon: Icons.shopping_cart,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: CustomButton(
                text: 'Sell My Property',
                onPressed: controller.openSellerLeadForm,
                icon: Icons.sell,
              ),
            ),
          ],
        ),

        const SizedBox(height: 12),

        // Secondary action button
        CustomButton(
          text: 'Calculate Rebate',
          onPressed: controller.openRebateCalculator,
          icon: Icons.calculate,
          isOutlined: true,
        ),
      ],
    );
  }

  Widget _buildPropertyDescription(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Description',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: AppTheme.black,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),

        Text(
          controller.property['description'] ??
              'This beautiful property offers modern amenities and a great location. Contact us for more details about this amazing opportunity.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: AppTheme.darkGray,
            height: 1.5,
          ),
        ),
      ],
    );
  }
}

class RebateDisclosureDialog extends StatefulWidget {
  final VoidCallback onAcknowledge;

  const RebateDisclosureDialog({super.key, required this.onAcknowledge});

  @override
  State<RebateDisclosureDialog> createState() => _RebateDisclosureDialogState();
}

class _RebateDisclosureDialogState extends State<RebateDisclosureDialog> {
  bool _hasRead = false;
  bool _acknowledged = false;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.primaryBlue.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
              ),
              child: Row(
                children: [
                  Icon(Icons.gavel, color: AppTheme.primaryBlue, size: 28),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Get a Rebate Real Estate — Rebate Disclosure',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.primaryBlue,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Get.back(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),

            // Content
            Flexible(
              child: NotificationListener<ScrollNotification>(
                onNotification: (notification) {
                  if (notification is ScrollEndNotification) {
                    final metrics = notification.metrics;
                    if (metrics.pixels >= metrics.maxScrollExtent - 50) {
                      setState(() => _hasRead = true);
                    }
                  }
                  return false;
                },
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryBlue.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppTheme.primaryBlue.withOpacity(0.2),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Rebate Disclosure Acknowledgment:',
                              style: Theme.of(context).textTheme.titleSmall
                                  ?.copyWith(
                                    color: AppTheme.primaryBlue,
                                    fontWeight: FontWeight.w700,
                                  ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'By proceeding, you acknowledge that Get a Rebate Real Estate connects you with agents and loan officers who have confirmed they offer or allow real estate commission rebates where permitted by law. Rebates must be disclosed in all agreements and approved by your lender, title company, and other parties. Real estate commissions are 100% negotiable, and rebate availability may vary by property, program, or state.',
                              style: Theme.of(context).textTheme.bodySmall
                                  ?.copyWith(
                                    color: AppTheme.darkGray,
                                    height: 1.5,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      _buildSection(
                        context,
                        '',
                        'The Get a Rebate Real Estate platform is designed to help buyers and sellers save money by sharing a portion of the real estate commission earned by participating agents. The availability and amount of a rebate will vary based on the total commission received and applicable state laws.',
                      ),
                      const SizedBox(height: 16),
                      _buildSection(
                        context,
                        'Buyer Rebates',
                        'All real estate agents featured on this site have agreed to provide a rebate to buyers who connect with them through this platform, in states where rebates are permitted by law. This rebate typically appears as a credit to the buyer on the settlement statement at closing.',
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'To ensure compliance, buyers must follow these steps:',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.darkGray,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      _buildBulletPoint(
                        context,
                        'Work with a loan officer who has confirmed that their lender allows real estate commission rebates and permits them to appear on the settlement statement as a credit to the buyer. Note that all loan officers on our site have confirmed that their lender allows/accepts rebates.',
                      ),
                      _buildBulletPoint(
                        context,
                        'Notify the title company or closer about the rebate in advance, confirming their ability to reflect the rebate on the settlement statement.',
                      ),
                      _buildBulletPoint(
                        context,
                        'Include rebate language in both the agent–client representation agreement and the purchase agreement so that all parties are aware.',
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Rebates are allowed in 40 states when these requirements are met; however, certain builders, sellers, loan programs, or first-time homebuyer programs may prohibit or restrict rebates. It is the buyer\'s responsibility to work with parties and programs that allow them.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.darkGray,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildSection(
                        context,
                        'Seller Rebates / Listing Adjustments',
                        'For sellers, agents on this site can use the rebate calculator provided on their profile pages to determine an adjusted listing fee percentage that factors in any agreed-upon rebate. This simplifies compliance and reduces the need for separate rebate disclosures.',
                      ),
                      const SizedBox(height: 16),
                      _buildSection(
                        context,
                        'Additional Disclosures',
                        'Real estate commissions are 100% negotiable and will vary by property, agent, and transaction.',
                      ),
                      const SizedBox(height: 8),
                      _buildBulletPoint(
                        context,
                        'Only agents listed on this platform have agreed to offer rebates.',
                      ),
                      _buildBulletPoint(
                        context,
                        'Rebates generally apply only when the seller or builder pays a commission to the agent representing the buyer.',
                      ),
                      _buildBulletPoint(
                        context,
                        'In rare cases where no buyer\'s agent commission is offered, the rebate may reduce the negotiated buyer–agent fee instead.',
                      ),
                      _buildBulletPoint(
                        context,
                        'Get a Rebate Real Estate does not represent any buyer or seller unless a signed representation agreement is executed directly with Get a Rebate Real Estate (in Minnesota).',
                      ),
                      _buildBulletPoint(
                        context,
                        'Despite best efforts, there may be situations where rebates are restricted or disallowed beyond the control of Get a Rebate Real Estate, participating agents, the buyers, the sellers, or loan officers.',
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.amber.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.amber.shade300),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.lightbulb_outline,
                              color: Colors.amber.shade700,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Real estate commissions are 100% negotiable.',
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(
                                      color: Colors.amber.shade900,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (!_hasRead) ...[
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.arrow_downward,
                                color: AppTheme.mediumGray,
                                size: 16,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'Scroll down to continue',
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(
                                      color: AppTheme.mediumGray,
                                      fontStyle: FontStyle.italic,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),

            // Acknowledgment
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.white,
                border: Border(
                  top: BorderSide(color: AppTheme.lightGray, width: 1),
                ),
              ),
              child: Column(
                children: [
                  CheckboxListTile(
                    value: _acknowledged,
                    onChanged: _hasRead
                        ? (value) => setState(() => _acknowledged = value!)
                        : null,
                    title: Text(
                      'I acknowledge that I have read and understand this rebate disclosure',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: _hasRead ? AppTheme.black : AppTheme.mediumGray,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    activeColor: AppTheme.primaryBlue,
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _acknowledged ? widget.onAcknowledge : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryBlue,
                        foregroundColor: AppTheme.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        disabledBackgroundColor: AppTheme.mediumGray,
                      ),
                      child: Text(
                        _acknowledged
                            ? 'I Understand'
                            : 'Please read acknowledge above',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: AppTheme.black,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          content,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: AppTheme.darkGray,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildBulletPoint(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, top: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '• ',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppTheme.primaryBlue,
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppTheme.darkGray,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
