import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RebateCalculatorController extends GetxController {
  // Form controllers
  final homePriceController = TextEditingController();
  final downPaymentController = TextEditingController();
  final loanAmountController = TextEditingController();
  final agentCommissionController = TextEditingController();
  final loanOfficerCommissionController = TextEditingController();

  // Observable variables
  final _isLoading = false.obs;
  final _selectedState = 'NY'.obs;
  final _selectedLoanType = 'Conventional'.obs;
  final _selectedPropertyType = 'Single Family'.obs;
  final _isFirstTimeBuyer = false.obs;
  final _hasPreApproval = false.obs;

  // Calculation results
  final _estimatedRebate = 0.0.obs;
  final _agentRebate = 0.0.obs;
  final _loanOfficerRebate = 0.0.obs;
  final _totalSavings = 0.0.obs;
  final _rebatePercentage = 0.0.obs;
  final _effectiveCommissionRate = 0.0.obs;
  final _commissionTier = ''.obs;

  // Getters
  bool get isLoading => _isLoading.value;
  String get selectedState => _selectedState.value;
  String get selectedLoanType => _selectedLoanType.value;
  String get selectedPropertyType => _selectedPropertyType.value;
  bool get isFirstTimeBuyer => _isFirstTimeBuyer.value;
  bool get hasPreApproval => _hasPreApproval.value;
  double get estimatedRebate => _estimatedRebate.value;
  double get agentRebate => _agentRebate.value;
  double get loanOfficerRebate => _loanOfficerRebate.value;
  double get totalSavings => _totalSavings.value;
  double get rebatePercentage => _rebatePercentage.value;
  double get effectiveCommissionRate => _effectiveCommissionRate.value;
  String get commissionTier => _commissionTier.value;

  // State options
  final List<String> states = [
    'NY',
    'CA',
    'TX',
    'FL',
    'IL',
    'PA',
    'OH',
    'GA',
    'NC',
    'MI',
    'NJ',
    'VA',
    'WA',
    'AZ',
    'MA',
    'TN',
    'IN',
    'MO',
    'MD',
    'WI',
  ];

  // Loan type options
  final List<String> loanTypes = ['Conventional', 'FHA', 'VA', 'USDA', 'Jumbo'];

  // Property type options
  final List<String> propertyTypes = [
    'Single Family',
    'Condo',
    'Townhouse',
    'Multi-Family',
    'Co-op',
  ];

  @override
  void onInit() {
    super.onInit();
    _setupListeners();
  }

  void _setupListeners() {
    homePriceController.addListener(_calculateRebate);
    downPaymentController.addListener(_calculateRebate);
    agentCommissionController.addListener(_calculateRebate);
    loanOfficerCommissionController.addListener(_calculateRebate);
  }

  void setSelectedState(String state) {
    _selectedState.value = state;
    _calculateRebate();
  }

  void setSelectedLoanType(String loanType) {
    _selectedLoanType.value = loanType;
    _calculateRebate();
  }

  void setSelectedPropertyType(String propertyType) {
    _selectedPropertyType.value = propertyType;
    _calculateRebate();
  }

  void toggleFirstTimeBuyer() {
    _isFirstTimeBuyer.value = !_isFirstTimeBuyer.value;
    _calculateRebate();
  }

  void togglePreApproval() {
    _hasPreApproval.value = !_hasPreApproval.value;
    _calculateRebate();
  }

  void _calculateRebate() {
    try {
      final homePrice = double.tryParse(homePriceController.text) ?? 0.0;
      final downPayment = double.tryParse(downPaymentController.text) ?? 0.0;
      final agentCommissionRate =
          double.tryParse(agentCommissionController.text) ?? 0.0;
      final loanOfficerCommissionRate =
          double.tryParse(loanOfficerCommissionController.text) ?? 0.0;

      if (homePrice <= 0) {
        _resetCalculations();
        return;
      }

      // Calculate loan amount
      final loanAmount = homePrice - downPayment;
      loanAmountController.text = loanAmount.toStringAsFixed(0);

      // Calculate commission amounts
      final agentCommissionAmount = homePrice * (agentCommissionRate / 100);
      final loanOfficerCommissionAmount =
          homePrice * (loanOfficerCommissionRate / 100);

      // Get rebate percentage based on agent commission rate
      final rebateData = _getRebatePercentage(agentCommissionRate);
      _rebatePercentage.value = rebateData['percentage'];
      _commissionTier.value = rebateData['tier'];

      // Calculate rebate amounts
      _agentRebate.value =
          agentCommissionAmount * (_rebatePercentage.value / 100);
      _loanOfficerRebate.value =
          loanOfficerCommissionAmount * 0.20; // 20% for loan officers

      // Total estimated rebate
      _estimatedRebate.value = _agentRebate.value + _loanOfficerRebate.value;

      // Calculate effective commission rate after rebate
      final totalCommission =
          agentCommissionAmount + loanOfficerCommissionAmount;
      final totalRebate = _estimatedRebate.value;
      _effectiveCommissionRate.value = totalCommission > 0
          ? ((totalCommission - totalRebate) / homePrice) * 100
          : 0.0;

      // Additional savings for first-time buyers
      final firstTimeBuyerBonus = _isFirstTimeBuyer.value ? 500.0 : 0.0;
      final preApprovalBonus = _hasPreApproval.value ? 200.0 : 0.0;

      _totalSavings.value =
          _estimatedRebate.value + firstTimeBuyerBonus + preApprovalBonus;
    } catch (e) {
      _resetCalculations();
    }
  }

  Map<String, dynamic> _getRebatePercentage(double commissionRate) {
    if (commissionRate >= 4.0) {
      return {'percentage': 40.0, 'tier': '4.0% or more'};
    } else if (commissionRate >= 3.01) {
      return {'percentage': 35.0, 'tier': '3.01% - 3.99%'};
    } else if (commissionRate >= 2.5) {
      return {'percentage': 30.0, 'tier': '2.5% - 3.0%'};
    } else if (commissionRate >= 2.0) {
      return {'percentage': 25.0, 'tier': '2.0% - 2.49%'};
    } else if (commissionRate >= 1.5) {
      return {'percentage': 20.0, 'tier': '1.5% - 1.99%'};
    } else {
      return {'percentage': 10.0, 'tier': '1.49% or below'};
    }
  }

  void _resetCalculations() {
    _estimatedRebate.value = 0.0;
    _agentRebate.value = 0.0;
    _loanOfficerRebate.value = 0.0;
    _totalSavings.value = 0.0;
    _rebatePercentage.value = 0.0;
    _effectiveCommissionRate.value = 0.0;
    _commissionTier.value = '';
  }

  void resetCalculator() {
    homePriceController.clear();
    downPaymentController.clear();
    loanAmountController.clear();
    agentCommissionController.clear();
    loanOfficerCommissionController.clear();
    _selectedState.value = 'NY';
    _selectedLoanType.value = 'Conventional';
    _selectedPropertyType.value = 'Single Family';
    _isFirstTimeBuyer.value = false;
    _hasPreApproval.value = false;
    _resetCalculations();
  }

  void findAgents() {
    // Navigate to agents page
    Get.toNamed('/agents');
  }

  void findLoanOfficers() {
    // Navigate to loan officers page
    Get.toNamed('/loan-officers');
  }

  @override
  void onClose() {
    homePriceController.dispose();
    downPaymentController.dispose();
    loanAmountController.dispose();
    agentCommissionController.dispose();
    loanOfficerCommissionController.dispose();
    super.onClose();
  }
}
