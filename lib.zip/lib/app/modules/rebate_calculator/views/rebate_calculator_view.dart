import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/theme/app_theme.dart';
import 'package:getrebate/app/modules/rebate_calculator/controllers/rebate_calculator_controller.dart';
import 'package:getrebate/app/widgets/custom_button.dart';
import 'package:getrebate/app/widgets/custom_text_field.dart';

class RebateCalculatorView extends GetView<RebateCalculatorController> {
  const RebateCalculatorView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              _buildHeader(context),

              const SizedBox(height: 24),

              // Calculator Form
              _buildCalculatorForm(context),

              const SizedBox(height: 24),

              // Results
              _buildResults(context),

              const SizedBox(height: 24),

              // Action Buttons
              _buildActionButtons(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () => Get.back(),
          icon: const Icon(Icons.arrow_back, color: AppTheme.darkGray),
        ),
        Expanded(
          child: Text(
            'Rebate Calculator',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: AppTheme.black,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        IconButton(
          onPressed: controller.resetCalculator,
          icon: const Icon(Icons.refresh, color: AppTheme.primaryBlue),
        ),
      ],
    );
  }

  Widget _buildCalculatorForm(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Property Details',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: AppTheme.black,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 20),

            // Home Price
            CustomTextField(
              controller: controller.homePriceController,
              labelText: 'Home Price',
              keyboardType: TextInputType.number,
              prefixIcon: Icons.home,
              hintText: 'Enter home price',
            ),

            const SizedBox(height: 16),

            // Down Payment
            CustomTextField(
              controller: controller.downPaymentController,
              labelText: 'Down Payment',
              keyboardType: TextInputType.number,
              prefixIcon: Icons.account_balance_wallet,
              hintText: 'Enter down payment amount',
            ),

            const SizedBox(height: 16),

            // Loan Amount (calculated)
            CustomTextField(
              controller: controller.loanAmountController,
              labelText: 'Loan Amount',
              keyboardType: TextInputType.number,
              prefixIcon: Icons.calculate,
              enabled: false,
              hintText: 'Calculated automatically',
            ),

            const SizedBox(height: 20),

            // State Selection
            _buildDropdown(
              context,
              'State',
              controller.selectedState,
              controller.states,
              controller.setSelectedState,
              Icons.location_on,
            ),

            const SizedBox(height: 16),

            // Loan Type Selection
            _buildDropdown(
              context,
              'Loan Type',
              controller.selectedLoanType,
              controller.loanTypes,
              controller.setSelectedLoanType,
              Icons.account_balance,
            ),

            const SizedBox(height: 16),

            // Property Type Selection
            _buildDropdown(
              context,
              'Property Type',
              controller.selectedPropertyType,
              controller.propertyTypes,
              controller.setSelectedPropertyType,
              Icons.home_work,
            ),

            const SizedBox(height: 20),

            // Commission Details
            Text(
              'Commission Details',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppTheme.black,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),

            CustomTextField(
              controller: controller.agentCommissionController,
              labelText: 'Agent Commission (%)',
              keyboardType: TextInputType.number,
              prefixIcon: Icons.person,
              hintText: 'e.g., 2.5 (4.0%+ = 40% rebate)',
            ),

            const SizedBox(height: 16),

            CustomTextField(
              controller: controller.loanOfficerCommissionController,
              labelText: 'Loan Officer Commission (%)',
              keyboardType: TextInputType.number,
              prefixIcon: Icons.account_balance,
              hintText: 'e.g., 1.0',
            ),

            const SizedBox(height: 20),

            // Commission Tier Reference
            _buildCommissionTierReference(context),

            const SizedBox(height: 20),

            // Checkboxes
            _buildCheckboxes(context),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(
    BuildContext context,
    String label,
    String value,
    List<String> items,
    Function(String) onChanged,
    IconData icon,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: AppTheme.darkGray,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppTheme.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: DropdownButtonFormField<String>(
            value: value,
            decoration: InputDecoration(
              prefixIcon: Icon(icon, color: AppTheme.mediumGray, size: 20),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
            ),
            items: items.map((String item) {
              return DropdownMenuItem<String>(value: item, child: Text(item));
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                onChanged(newValue);
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCommissionTierReference(BuildContext context) {
    return ExpansionTile(
      title: Text(
        'Commission Tier Reference',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          color: AppTheme.black,
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: const Text('View rebate percentages by commission rate'),
      iconColor: AppTheme.primaryBlue,
      collapsedIconColor: AppTheme.mediumGray,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.lightGray,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            children: [
              _buildTierRow(
                context,
                '4.0% or more',
                '40% rebate',
                AppTheme.lightGreen,
              ),
              _buildTierRow(
                context,
                '3.01% - 3.99%',
                '35% rebate',
                AppTheme.lightBlue,
              ),
              _buildTierRow(
                context,
                '2.5% - 3.0%',
                '30% rebate',
                AppTheme.mediumGray,
              ),
              _buildTierRow(
                context,
                '2.0% - 2.49%',
                '25% rebate',
                AppTheme.mediumGray,
              ),
              _buildTierRow(
                context,
                '1.5% - 1.99%',
                '20% rebate',
                AppTheme.mediumGray,
              ),
              _buildTierRow(
                context,
                '1.49% or below',
                '10% rebate',
                AppTheme.mediumGray,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTierRow(
    BuildContext context,
    String commissionRange,
    String rebate,
    Color color,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            commissionRange,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: AppTheme.darkGray,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            rebate,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckboxes(BuildContext context) {
    return Column(
      children: [
        Obx(
          () => CheckboxListTile(
            title: const Text('First-time home buyer'),
            subtitle: const Text('Eligible for additional rebates'),
            value: controller.isFirstTimeBuyer,
            onChanged: (_) => controller.toggleFirstTimeBuyer(),
            activeColor: AppTheme.primaryBlue,
            contentPadding: EdgeInsets.zero,
          ),
        ),
        Obx(
          () => CheckboxListTile(
            title: const Text('Pre-approved for loan'),
            subtitle: const Text('Eligible for additional savings'),
            value: controller.hasPreApproval,
            onChanged: (_) => controller.togglePreApproval(),
            activeColor: AppTheme.primaryBlue,
            contentPadding: EdgeInsets.zero,
          ),
        ),
      ],
    );
  }

  Widget _buildResults(BuildContext context) {
    return Obx(
      () => Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Estimated Rebates',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTheme.black,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),

              if (controller.estimatedRebate > 0) ...[
                // Commission Tier Display
                _buildCommissionTierCard(context),

                const SizedBox(height: 16),

                // Total Estimated Rebate
                _buildResultItem(
                  context,
                  'Total Estimated Rebate',
                  '\$${controller.estimatedRebate.toStringAsFixed(0)}',
                  AppTheme.primaryBlue,
                  Icons.attach_money,
                ),

                const SizedBox(height: 16),

                // Breakdown
                _buildResultItem(
                  context,
                  'Agent Rebate (${controller.rebatePercentage.toStringAsFixed(0)}%)',
                  '\$${controller.agentRebate.toStringAsFixed(0)}',
                  AppTheme.lightGreen,
                  Icons.person,
                ),

                const SizedBox(height: 8),

                _buildResultItem(
                  context,
                  'Loan Officer Rebate (20%)',
                  '\$${controller.loanOfficerRebate.toStringAsFixed(0)}',
                  AppTheme.lightBlue,
                  Icons.account_balance,
                ),

                const SizedBox(height: 16),

                // Effective Commission Rate
                _buildResultItem(
                  context,
                  'Effective Commission Rate',
                  '${controller.effectiveCommissionRate.toStringAsFixed(2)}%',
                  AppTheme.mediumGray,
                  Icons.trending_down,
                ),

                const SizedBox(height: 16),

                // Total Savings
                _buildResultItem(
                  context,
                  'Total Savings',
                  '\$${controller.totalSavings.toStringAsFixed(0)}',
                  AppTheme.lightGreen,
                  Icons.savings,
                  isHighlighted: true,
                ),

                const SizedBox(height: 16),

                // Disclaimer
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.lightGray,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'These are estimated rebates. Actual rebates may vary based on specific agent and loan officer agreements.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.mediumGray,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ] else ...[
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.lightGray,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.calculate,
                        size: 48,
                        color: AppTheme.mediumGray,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Enter property details to calculate your rebate',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppTheme.mediumGray,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCommissionTierCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryBlue.withOpacity(0.1),
            AppTheme.lightBlue.withOpacity(0.1),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.percent, color: AppTheme.primaryBlue, size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Commission Tier',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppTheme.primaryBlue,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                controller.commissionTier,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppTheme.primaryBlue,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.local_offer, color: AppTheme.lightGreen, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Rebate Percentage',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.darkGray,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              Text(
                '${controller.rebatePercentage.toStringAsFixed(0)}%',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTheme.lightGreen,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResultItem(
    BuildContext context,
    String label,
    String value,
    Color color,
    IconData icon, {
    bool isHighlighted = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isHighlighted ? color.withOpacity(0.1) : AppTheme.white,
        borderRadius: BorderRadius.circular(8),
        border: isHighlighted ? Border.all(color: color, width: 2) : null,
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: AppTheme.darkGray,
                fontWeight: isHighlighted ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Obx(
      () => Column(
        children: [
          if (controller.estimatedRebate > 0) ...[
            CustomButton(
              text: 'Find Agents',
              onPressed: controller.findAgents,
              icon: Icons.person_search,
              width: double.infinity,
            ),
            const SizedBox(height: 12),
            CustomButton(
              text: 'Find Loan Officers',
              onPressed: controller.findLoanOfficers,
              icon: Icons.account_balance,
              isOutlined: true,
              width: double.infinity,
            ),
          ] else ...[
            CustomButton(
              text: 'Calculate Rebate',
              onPressed: () {
                if (controller.homePriceController.text.isEmpty) {
                  Get.snackbar('Error', 'Please enter a home price');
                }
              },
              icon: Icons.calculate,
              width: double.infinity,
            ),
          ],
        ],
      ),
    );
  }
}
