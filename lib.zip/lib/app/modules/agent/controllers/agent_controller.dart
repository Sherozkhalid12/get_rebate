import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/models/zip_code_model.dart';
import 'package:getrebate/app/models/agent_listing_model.dart';

class AgentController extends GetxController {
  // Data
  final _claimedZipCodes = <ZipCodeModel>[].obs;
  final _availableZipCodes = <ZipCodeModel>[].obs;
  final _myListings = <AgentListingModel>[].obs;
  final _isLoading = false.obs;
  final _selectedTab = 0
      .obs; // 0: Dashboard, 1: ZIP Management, 2: My Listings, 3: Billing, 4: Stats

  // Stats
  final _searchesAppearedIn = 0.obs;
  final _profileViews = 0.obs;
  final _contacts = 0.obs;
  final _websiteClicks = 0.obs;
  final _totalRevenue = 0.0.obs;

  // Getters
  List<ZipCodeModel> get claimedZipCodes => _claimedZipCodes;
  List<ZipCodeModel> get availableZipCodes => _availableZipCodes;
  List<AgentListingModel> get myListings => _myListings;
  bool get isLoading => _isLoading.value;
  int get selectedTab => _selectedTab.value;
  int get searchesAppearedIn => _searchesAppearedIn.value;
  int get profileViews => _profileViews.value;
  int get contacts => _contacts.value;
  int get websiteClicks => _websiteClicks.value;
  double get totalRevenue => _totalRevenue.value;

  // Listing limits
  int get freeListingLimit => 3;
  int get currentListingCount => _myListings.length;
  int get remainingFreeListings =>
      (freeListingLimit - currentListingCount).clamp(0, freeListingLimit);
  bool get canAddFreeListing => remainingFreeListings > 0;
  double get additionalListingPrice => 9.99;

  @override
  void onInit() {
    super.onInit();
    _loadMockData();
  }

  void setSelectedTab(int index) {
    _selectedTab.value = index;
  }

  void _loadMockData() {
    // Mock claimed ZIP codes
    _claimedZipCodes.value = [
      ZipCodeModel(
        zipCode: '10001',
        state: 'NY',
        population: 50000,
        claimedByAgent: 'agent_1',
        claimedAt: DateTime.now().subtract(const Duration(days: 30)),
        price: 299.99,
        isAvailable: false,
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
        searchCount: 45,
      ),
      ZipCodeModel(
        zipCode: '10002',
        state: 'NY',
        population: 45000,
        claimedByAgent: 'agent_1',
        claimedAt: DateTime.now().subtract(const Duration(days: 15)),
        price: 249.99,
        isAvailable: false,
        createdAt: DateTime.now().subtract(const Duration(days: 15)),
        searchCount: 32,
      ),
    ];

    // Mock available ZIP codes
    _availableZipCodes.value = [
      ZipCodeModel(
        zipCode: '10003',
        state: 'NY',
        population: 40000,
        price: 199.99,
        isAvailable: true,
        createdAt: DateTime.now(),
        searchCount: 0,
      ),
      ZipCodeModel(
        zipCode: '10004',
        state: 'NY',
        population: 35000,
        price: 179.99,
        isAvailable: true,
        createdAt: DateTime.now(),
        searchCount: 0,
      ),
      ZipCodeModel(
        zipCode: '10005',
        state: 'NY',
        population: 30000,
        price: 159.99,
        isAvailable: true,
        createdAt: DateTime.now(),
        searchCount: 0,
      ),
    ];

    // Mock listings
    _myListings.value = [
      AgentListingModel(
        id: 'listing_1',
        agentId: 'agent_1',
        title: 'Beautiful 3BR Condo in Manhattan',
        description:
            'Stunning 3-bedroom condo with city views, modern kitchen, and premium finishes.',
        priceCents: 125000000, // $1,250,000
        address: '123 Park Avenue',
        city: 'New York',
        state: 'NY',
        zipCode: '10001',
        photoUrls: [
          'https://images.unsplash.com/photo-1560185008-b033106af2fb?w=800&h=600&fit=crop',
          'https://images.unsplash.com/photo-1560185127-6c4a0b4b0b0b?w=800&h=600&fit=crop',
        ],
        bacPercent: 2.5,
        dualAgencyAllowed: true,
        isActive: true,
        isApproved: true,
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
        approvedAt: DateTime.now().subtract(const Duration(days: 28)),
        searchCount: 45,
        viewCount: 234,
        contactCount: 12,
      ),
      AgentListingModel(
        id: 'listing_2',
        agentId: 'agent_1',
        title: 'Luxury Penthouse with Terrace',
        description:
            'Exclusive penthouse featuring private terrace, panoramic views, and luxury amenities.',
        priceCents: 250000000, // $2,500,000
        address: '456 Central Park West',
        city: 'New York',
        state: 'NY',
        zipCode: '10002',
        photoUrls: [
          'https://images.unsplash.com/photo-1560185008-b033106af2fb?w=800&h=600&fit=crop',
        ],
        bacPercent: 3.0,
        dualAgencyAllowed: false,
        isActive: true,
        isApproved: true,
        createdAt: DateTime.now().subtract(const Duration(days: 15)),
        approvedAt: DateTime.now().subtract(const Duration(days: 12)),
        searchCount: 32,
        viewCount: 156,
        contactCount: 8,
      ),
      AgentListingModel(
        id: 'listing_3',
        agentId: 'agent_1',
        title: 'Modern Studio in SoHo',
        description:
            'Chic studio apartment in trendy SoHo neighborhood, perfect for young professionals.',
        priceCents: 75000000, // $750,000
        address: '789 Broadway',
        city: 'New York',
        state: 'NY',
        zipCode: '10003',
        photoUrls: [],
        bacPercent: 2.0,
        dualAgencyAllowed: true,
        isActive: true,
        isApproved: false,
        createdAt: DateTime.now().subtract(const Duration(days: 5)),
        searchCount: 8,
        viewCount: 23,
        contactCount: 2,
      ),
    ];

    // Mock stats
    _searchesAppearedIn.value = 77;
    _profileViews.value = 234;
    _contacts.value = 89;
    _websiteClicks.value = 156;
    _totalRevenue.value = 1249.99;
  }

  Future<void> claimZipCode(ZipCodeModel zipCode) async {
    try {
      _isLoading.value = true;

      // Check if agent can claim more ZIP codes (max 6)
      if (_claimedZipCodes.length >= 6) {
        Get.snackbar('Error', 'You can only claim up to 6 ZIP codes');
        return;
      }

      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Add to claimed ZIP codes
      final claimedZip = zipCode.copyWith(
        claimedByAgent: 'agent_1',
        claimedAt: DateTime.now(),
        isAvailable: false,
      );

      _claimedZipCodes.add(claimedZip);
      _availableZipCodes.removeWhere((zip) => zip.zipCode == zipCode.zipCode);

      Get.snackbar(
        'Success',
        'ZIP code ${zipCode.zipCode} claimed successfully!',
      );
    } catch (e) {
      Get.snackbar('Error', 'Failed to claim ZIP code: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> releaseZipCode(ZipCodeModel zipCode) async {
    try {
      _isLoading.value = true;

      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Remove from claimed ZIP codes
      _claimedZipCodes.removeWhere((zip) => zip.zipCode == zipCode.zipCode);

      // Add back to available ZIP codes
      final availableZip = zipCode.copyWith(
        claimedByAgent: null,
        claimedAt: null,
        isAvailable: true,
      );

      _availableZipCodes.add(availableZip);

      Get.snackbar(
        'Success',
        'ZIP code ${zipCode.zipCode} released successfully!',
      );
    } catch (e) {
      Get.snackbar('Error', 'Failed to release ZIP code: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> searchZipCodes(String query) async {
    try {
      _isLoading.value = true;

      // Simulate API call
      await Future.delayed(const Duration(milliseconds: 500));

      // Filter available ZIP codes by query
      final filteredZips = _availableZipCodes
          .where(
            (zip) =>
                zip.zipCode.contains(query) ||
                zip.state.toLowerCase().contains(query.toLowerCase()),
          )
          .toList();

      _availableZipCodes.value = filteredZips;
    } catch (e) {
      Get.snackbar('Error', 'Search failed: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  void notifyMeWhenAvailable(String zipCode) {
    Get.snackbar(
      'Notification Set',
      'You will be notified when ZIP code $zipCode becomes available',
    );
  }

  double calculateMonthlyCost() {
    return _claimedZipCodes.fold(0.0, (sum, zip) => sum + zip.price);
  }

  List<Map<String, dynamic>> getStatsData() {
    return [
      {'label': 'Searches', 'value': searchesAppearedIn, 'icon': Icons.search},
      {
        'label': 'Profile Views',
        'value': profileViews,
        'icon': Icons.visibility,
      },
      {'label': 'Contacts', 'value': contacts, 'icon': Icons.phone},
      {'label': 'Revenue', 'value': totalRevenue, 'icon': Icons.attach_money},
    ];
  }

  // Listing Management Methods
  Future<void> addListing(AgentListingModel listing) async {
    try {
      _isLoading.value = true;

      // Check if agent can add more listings
      // Note: Agents can always add listings for $9.99 per listing, even without subscription
      // The free limit only applies to the first 3 listings
      if (!canAddFreeListing) {
        // This case shouldn't block adding listings, but we'll show info
        // The UI will handle showing the purchase option
      }

      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Add new listing
      _myListings.add(listing);

      Get.snackbar(
        'Success',
        'Listing added successfully! It will be reviewed before going live.',
      );
    } catch (e) {
      Get.snackbar('Error', 'Failed to add listing: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> updateListing(AgentListingModel listing) async {
    try {
      _isLoading.value = true;

      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Update listing
      final index = _myListings.indexWhere((l) => l.id == listing.id);
      if (index != -1) {
        _myListings[index] = listing;
        Get.snackbar('Success', 'Listing updated successfully!');
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to update listing: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> deleteListing(String listingId) async {
    try {
      _isLoading.value = true;

      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Remove listing
      _myListings.removeWhere((listing) => listing.id == listingId);

      Get.snackbar('Success', 'Listing deleted successfully!');
    } catch (e) {
      Get.snackbar('Error', 'Failed to delete listing: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> toggleListingStatus(String listingId) async {
    try {
      _isLoading.value = true;

      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Toggle listing status
      final index = _myListings.indexWhere((l) => l.id == listingId);
      if (index != -1) {
        final listing = _myListings[index];
        _myListings[index] = listing.copyWith(
          isActive: !listing.isActive,
          updatedAt: DateTime.now(),
        );

        final status = _myListings[index].isActive
            ? 'activated'
            : 'deactivated';
        Get.snackbar('Success', 'Listing $status successfully!');
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to update listing status: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  Future<void> purchaseAdditionalListing() async {
    try {
      _isLoading.value = true;

      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 2));

      // In a real app, this would process payment for a new listing
      // The $9.99 fee covers the listing until it sells (one-time fee)
      Get.snackbar(
        'Success',
        'Listing payment processed! You can now add your listing. This one-time fee covers your listing until it sells.',
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to process listing payment: ${e.toString()}',
      );
    } finally {
      _isLoading.value = false;
    }
  }

  // Legacy method name for backwards compatibility
  Future<void> purchaseAdditionalListingSlot() async {
    return purchaseAdditionalListing();
  }

  // Listing stats
  int get totalListingViews =>
      _myListings.fold(0, (sum, listing) => sum + listing.viewCount);
  int get totalListingContacts =>
      _myListings.fold(0, (sum, listing) => sum + listing.contactCount);
  int get totalListingSearches =>
      _myListings.fold(0, (sum, listing) => sum + listing.searchCount);
  int get activeListingsCount =>
      _myListings.where((l) => l.isActive && l.isApproved).length;
  int get pendingListingsCount =>
      _myListings.where((l) => !l.isApproved).length;
}
