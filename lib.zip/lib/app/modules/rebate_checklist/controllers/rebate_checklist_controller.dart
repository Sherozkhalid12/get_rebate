import 'package:get/get.dart';

class RebateChecklistController extends GetxController {
  List<String> getRebateChecklistForBuying() {
    return [
      'Confirm State Eligibility: Verify that the buyer is purchasing or building in a state that allows real estate rebates. These 10 states currently do not allow real estate rebates: Alabama, Alaska, Kansas, Louisiana, Mississippi, Missouri, Oklahoma, Oregon, Tennessee, and Iowa.',
      'Include Rebate Language in the Buyer Representation Agreement: Use the recommended rebate wording (or a similar version approved by your broker).',
      'Verify Loan Officer and Lender Participation: Ensure the buyer is pre-approved with a loan officer whose lender allows real estate rebates. (Agents and buyers can search this site for a list of confirmed loan officers.)',
      'Coordinate Seller Concessions and Rebate Limits: Confirm with the buyer\'s loan officer whether "seller concessions" will be requested in the offer. Determine the maximum amount allowed, including the rebate, to ensure the buyer receives the full benefit. Some lenders handle seller concessions and rebates separately—clarify how the lender manages this. It\'s often helpful to review the numbers with the loan officer before submitting the offer.',
      'Review Special Financing Programs: If the buyer is using special financing programs (e.g., first-time homebuyer grants, state or city programs), note that some may restrict or prohibit rebates. Buyers must work with programs and lenders that allow rebates. Make sure buyers understand how their financing decisions may affect rebate eligibility.',
      'For New Construction Purchases: Confirm with the builder that rebates are allowed. Most builders permit them, but some may restrict or prohibit them. If an issue arises, contact us for alternative ideas to try.',
      'Notify the Title or Closing Company Early: Inform the title or closing company that the transaction will include a rebate. Experienced closers will know how to properly document this, though some may need to confirm internal procedures. The rebate should appear on the settlement statement as a credit to the buyer.',
      'Calculate and Verify the Rebate Amount: Use the Rebate Calculator on the site to determine the rebate amount. Buyers also have access to this tool. Because the rebate may change during negotiations, confirm the final amount once the offer is accepted and all contingencies are removed.',
      'Include Rebate Disclosure and Commission Split in the Offer: When submitting an offer, include the rebate disclosure and commission split language (or broker-approved equivalent).',
      'After Closing: Encourage the Buyer to leave feedback on your GetaRebate.com profile — this helps build your reputation and visibility. If a rebate was given, the actual rebate amount will be on the settlement statement and the closer should point it out to the Buyer. Make sure Buyer knows how much money they saved working with you from the rebate so they can refer you to family and friends!',
    ];
  }

  List<String> getRebateChecklistForSelling() {
    return [
      'Confirm Rebate Eligibility: Verify that the property is located in a state that allows real estate rebates. Currently, 11 states do not allow rebates when selling: Alabama, Alaska, Kansas, Louisiana, Mississippi, Missouri, Oklahoma, Oregon, Tennessee, New Jersey, and Iowa.',
      'Update the Listing Agreement: Include the rebate or reduced listing fee disclosure language (see provided amendment or broker-approved wording). Make sure both you and the Seller sign and understand the rebate or listing fee arrangement.',
      'Choose How the Savings Will Be Applied: Option 1 - Lower Listing Fee (No Rebate): If you and the Seller agree to a lower listing fee instead of a rebate at closing, no rebate disclosure is needed. This option is valid in all 50 states, since no funds are rebated—just a reduced commission. Option 2 - Seller Rebate at Closing: If you and the Seller choose the rebate option, it can only be used in states that allow rebates. Add the Listing Agent Rebate Disclosure (or broker-approved equivalent) to the purchase agreement.',
      'Notify the Title/Closing Company: Contact the title or closing company early to let them know a rebate will be part of the transaction. Confirm any special documentation or instructions they may require. The rebate should appear on the settlement statement as a credit to the Seller if the rebate option is chosen.',
      'Confirm Final Rebate or Fee Reduction Amount: Use the Seller Rebate Conversion Calculator on GetaRebate.com to determine the correct amount or fee. Adjust the amount if the final commission or negotiated terms change.',
      'After Closing: Encourage the Seller to leave feedback on your GetaRebate.com profile — this helps build your reputation and visibility. If a rebate was given, the actual rebate amount will show on the settlement statement and the closer should point it out to the Seller at closing. If you used the lower listing fee option, use the calculator to show what that savings equates to. It\'s best that the seller knows the dollar amount they ended up saving so they can tell friends to refer you to!',
    ];
  }

  /// Returns the rebate addendum wording for the Buyer Representation Agreement (Step #2)
  String getRebateAddendumForBuyerRepresentation() {
    return '''Rebate Disclosure and Agreement

Rebate Terms (Addendum):
Buyer and Broker acknowledge and agree that Broker participates in the rebate program as described on GetaRebate.com site and app/platform. Broker agrees to provide Buyer with a real estate commission rebate ("Rebate") based on the property's final purchase price and the Buyer Agent Compensation ("BAC") as negotiated and stated in the fully executed Purchase Agreement.

Rebate Calculation:
The Rebate shall be calculated as a percentage of the total commission actually received by the Broker according to the following schedule:

Buyer Agent Compensation (BAC)          | Rebate Percentage of Total Commission Received
--------------------------------------|-----------------------------------------------
4.0% or higher                        | 40%
3.01% – 3.99%                         | 35%
2.5% – 3.0%                           | 30%
2.0% – 2.49%                          | 25%
1.5% – 1.99%                          | 20%
1.49% or less                         | 10%

For purchase prices of \$1,000,000 or more, the minimum rebate shall be 25% of the total commission received by the Broker.

Payment of Rebate:
The Rebate is typically credited to Buyer at closing as a credit toward Buyer's closing costs on the final settlement statement. Payment is subject to approval by Buyer's lender, title company, and any other party involved in the transaction. The Rebate amount may be reduced or disallowed if it exceeds limits imposed by the lender or applicable loan program.

Conditions:
• The Rebate applies only where a Buyer Agent Compensation is paid to the Broker.
• The Rebate amount may vary if the BAC or compensation terms are modified during negotiation or as required to comply with legal, lender, or title restrictions.
• All real estate commissions are fully negotiable between the parties.
• If the Rebate cannot be credited at closing due to lender or program restrictions, the Broker may, at Broker's discretion and subject to applicable laws, issue payment to Buyer after closing.
• The Buyer is responsible for verifying that the Rebate is permitted under their chosen financing program, loan terms, and applicable state laws.

Acknowledgment:
Buyer acknowledges understanding of the Rebate program and authorizes Broker to disclose the Rebate terms to the seller, title company, lender, and any other necessary party to ensure proper documentation and compliance.''';
  }

  /// Returns the rebate disclosure wording for the Purchase Offer (Step #9)
  String getRebateDisclosureForPurchaseOffer() {
    return '''Real Estate Commission Rebate and Commission Split Disclosure:
Buyer, Seller, and Listing Brokerage acknowledge and agree that the total real estate commission shall be split between the Listing Brokerage and the Buyer's Brokerage at closing, allowing the Buyer's Brokerage to provide a rebate to the Buyer as a credit on the settlement statement.

Buyer and Seller acknowledge that Buyer's Agent has agreed to provide a real estate commission rebate to Buyer in the amount of \$____, or as otherwise agreed upon in writing, subject to approval and acceptance by Buyer's lender of choice. Said rebate shall generally be applied as a credit to Buyer's allowable closing costs on the final settlement statement, provided such credit is permitted by applicable lending guidelines and closing instructions.

The final rebate amount may be adjusted based on negotiated terms of the Purchase Agreement, lender requirements, and applicable state or federal laws. All parties acknowledge that the real estate commission is fully negotiable and that this rebate has been properly disclosed in accordance with state law, lender policy, and the terms of Buyer's agency agreement.''';
  }

  /// Returns the rebate disclosure wording for Seller Listing Agreement (Step #3)
  String getRebateDisclosureForListingAgreement() {
    return '''Listing Agent Rebate Disclosure:
Seller and Listing Brokerage acknowledge and agree that Listing Brokerage has elected to provide a real estate commission rebate to Seller in the amount of \$____. This rebate shall be applied as a credit to Seller on the final settlement statement, unless otherwise agreed to in writing. The final amount may be adjusted based on negotiated terms, lender requirements, and applicable state or federal laws. All parties acknowledge that real estate commission is fully negotiable and that this rebate has been properly disclosed in accordance with state law and brokerage policy.''';
  }
}
