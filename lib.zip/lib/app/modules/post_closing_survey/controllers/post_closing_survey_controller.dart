import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/models/post_closing_survey_model.dart';
import 'package:getrebate/app/services/survey_rating_service.dart';

class PostClosingSurveyController extends GetxController {
  // Survey data passed as arguments
  late final String agentId;
  late final String agentName;
  late final String userId;
  late final String transactionId;
  late final bool isBuyer;

  // Text controllers
  final rebateAmountController = TextEditingController();
  final rebateApplicationOtherController = TextEditingController();
  final additionalCommentsController = TextEditingController();

  // Observable survey responses
  final _rebateAmount = 0.0.obs;
  final _receivedExpectedRebate = Rxn<ReceivedExpectedRebate>();
  final _rebateApplicationMethod = Rxn<RebateApplicationMethod>();
  final _signedDisclosure = Rxn<SignedDisclosure>();
  final _overallSatisfaction = Rxn<int>();
  final _rebateEase = Rxn<RebateEase>();
  final _recommendationLevel = Rxn<RecommendationLevel>();
  final _agentRating = Rxn<int>();

  // State management
  final _currentStep = 0.obs;
  final _isLoading = false.obs;
  final _rebateAmountSaved = false.obs;

  // Getters
  double get rebateAmount => _rebateAmount.value;
  ReceivedExpectedRebate? get receivedExpectedRebate =>
      _receivedExpectedRebate.value;
  RebateApplicationMethod? get rebateApplicationMethod =>
      _rebateApplicationMethod.value;
  SignedDisclosure? get signedDisclosure => _signedDisclosure.value;
  int? get overallSatisfaction => _overallSatisfaction.value;
  RebateEase? get rebateEase => _rebateEase.value;
  RecommendationLevel? get recommendationLevel => _recommendationLevel.value;
  int? get agentRating => _agentRating.value;
  int get currentStep => _currentStep.value;
  bool get isLoading => _isLoading.value;
  bool get rebateAmountSaved => _rebateAmountSaved.value;

  @override
  void onInit() {
    super.onInit();
    // Get arguments from navigation
    final args = Get.arguments as Map<String, dynamic>?;
    agentId = args?['agentId'] ?? '';
    agentName = args?['agentName'] ?? 'your agent';
    userId = args?['userId'] ?? '';
    transactionId = args?['transactionId'] ?? '';
    isBuyer = args?['isBuyer'] ?? true;
  }

  @override
  void onClose() {
    rebateAmountController.dispose();
    rebateApplicationOtherController.dispose();
    additionalCommentsController.dispose();
    super.onClose();
  }

  /// Save rebate amount immediately when entered
  Future<void> saveRebateAmount() async {
    final amount = double.tryParse(rebateAmountController.text);
    if (amount == null || amount <= 0) {
      // Silently prevent saving invalid amount
      return;
    }

    _isLoading.value = true;

    try {
      _rebateAmount.value = amount;

      // TODO: Save to backend immediately
      // await _surveyService.saveRebateAmount(userId, transactionId, amount);

      _rebateAmountSaved.value = true;

      // Rebate amount saved silently
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to save rebate amount. Please try again.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red.shade700,
      );
    } finally {
      _isLoading.value = false;
    }
  }

  void setReceivedExpectedRebate(ReceivedExpectedRebate value) {
    _receivedExpectedRebate.value = value;
  }

  void setRebateApplicationMethod(RebateApplicationMethod value) {
    _rebateApplicationMethod.value = value;
  }

  void setSignedDisclosure(SignedDisclosure value) {
    _signedDisclosure.value = value;
  }

  void setOverallSatisfaction(int value) {
    _overallSatisfaction.value = value;
  }

  void setRebateEase(RebateEase value) {
    _rebateEase.value = value;
  }

  void setRecommendationLevel(RecommendationLevel value) {
    _recommendationLevel.value = value;
  }

  void setAgentRating(int value) {
    _agentRating.value = value;
  }

  void nextStep() {
    if (_currentStep.value < 8) {
      _currentStep.value++;
    }
  }

  void previousStep() {
    if (_currentStep.value > 0) {
      _currentStep.value--;
    }
  }

  bool canProceedFromCurrentStep() {
    switch (_currentStep.value) {
      case 0: // Rebate amount
        return _rebateAmount.value > 0;
      case 1: // Received expected rebate
        return _receivedExpectedRebate.value != null;
      case 2: // Rebate application method
        if (_rebateApplicationMethod.value == null) return false;
        if (_rebateApplicationMethod.value == RebateApplicationMethod.other) {
          return rebateApplicationOtherController.text.isNotEmpty;
        }
        return true;
      case 3: // Signed disclosure
        return _signedDisclosure.value != null;
      case 4: // Overall satisfaction
        return _overallSatisfaction.value != null;
      case 5: // Rebate ease
        return _rebateEase.value != null;
      case 6: // Recommendation level
        return _recommendationLevel.value != null;
      case 7: // Additional comments (optional)
        return true; // Always can proceed since optional
      case 8: // Agent rating
        return _agentRating.value != null;
      default:
        return false;
    }
  }

  Future<void> submitSurvey() async {
    if (!canProceedFromCurrentStep()) {
      // Silently prevent submission if question not answered
      return;
    }

    _isLoading.value = true;

    try {
      final survey = PostClosingSurvey(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        agentId: agentId,
        userId: userId,
        transactionId: transactionId,
        isBuyer: isBuyer,
        rebateAmount: _rebateAmount.value,
        receivedExpectedRebate: _receivedExpectedRebate.value,
        rebateApplicationMethod: _rebateApplicationMethod.value,
        rebateApplicationOther:
            _rebateApplicationMethod.value == RebateApplicationMethod.other
            ? rebateApplicationOtherController.text
            : null,
        signedDisclosure: _signedDisclosure.value,
        overallSatisfaction: _overallSatisfaction.value,
        rebateEase: _rebateEase.value,
        recommendationLevel: _recommendationLevel.value,
        additionalComments: additionalCommentsController.text.isNotEmpty
            ? additionalCommentsController.text
            : null,
        agentRating: _agentRating.value,
        createdAt: DateTime.now(),
        completedAt: DateTime.now(),
        isComplete: true,
      );

      // Calculate the score
      final score = SurveyRatingService.calculateScore(survey);
      final surveyWithScore = survey.copyWith(calculatedScore: score);

      // TODO: Submit to backend
      // await _surveyService.submitSurvey(surveyWithScore);

      // Show success message
      Get.snackbar(
        'Thank You!',
        'Your feedback has been submitted successfully',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.1),
        colorText: Colors.green.shade700,
        duration: const Duration(seconds: 3),
      );

      // Navigate back or to a thank you page
      await Future.delayed(const Duration(seconds: 2));
      Get.back(result: surveyWithScore);
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to submit survey. Please try again.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red.shade700,
      );
    } finally {
      _isLoading.value = false;
    }
  }
}
