import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:getrebate/app/modules/post_closing_survey/controllers/post_closing_survey_controller.dart';
import 'package:getrebate/app/models/post_closing_survey_model.dart';
import 'package:getrebate/app/theme/app_theme.dart';

class PostClosingSurveyView extends GetView<PostClosingSurveyController> {
  const PostClosingSurveyView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightGray,
      appBar: AppBar(
        title: Text(
          'Post-Closing Survey',
          style: TextStyle(
            color: AppTheme.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: AppTheme.primaryBlue,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: AppTheme.primaryGradient,
            ),
          ),
        ),
        centerTitle: true,
      ),
      body: Obx(
        () => Column(
          children: [
            // Progress indicator
            _buildProgressIndicator(),

            // Survey content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(24.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Survey header (shown only on first step)
                    if (controller.currentStep == 0) ...[
                      _buildSurveyHeader(context),
                      SizedBox(height: 32.h),
                    ],

                    // Current question
                    _buildCurrentQuestion(context),
                  ],
                ),
              ),
            ),

            // Navigation buttons
            _buildNavigationButtons(context),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Container(
      margin: EdgeInsets.all(16.w),
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10.r,
            offset: Offset(0, 4.h),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Question ${controller.currentStep + 1} of 9',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.darkGray,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: AppTheme.primaryBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Text(
                  '${((controller.currentStep + 1) / 9 * 100).round()}%',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryBlue,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          LinearProgressIndicator(
            value: (controller.currentStep + 1) / 9,
            backgroundColor: AppTheme.lightGray,
            valueColor: const AlwaysStoppedAnimation<Color>(
              AppTheme.primaryBlue,
            ),
            minHeight: 8.h,
            borderRadius: BorderRadius.circular(4.r),
          ),
        ],
      ),
    );
  }

  Widget _buildSurveyHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(24.w),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10.r,
            offset: Offset(0, 4.h),
          ),
        ],
        border: Border.all(
          color: AppTheme.primaryBlue.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(12.w),
                decoration: BoxDecoration(
                  color: AppTheme.primaryBlue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Icon(
                  Icons.rate_review,
                  color: AppTheme.primaryBlue,
                  size: 24.sp,
                ),
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Text(
                  'Thank you for working with ${controller.agentName}!',
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.darkGray,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16.h),
          Text(
            'We\'re working to create a great resource for buyers and sellers to save money when buying, building, and selling real estate. Your feedback helps us - and future buyers and sellers - learn more about the experience you had with your agent.',
            style: TextStyle(
              fontSize: 14.sp,
              color: AppTheme.darkGray,
              height: 1.5,
            ),
          ),
          SizedBox(height: 12.h),
          Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: AppTheme.primaryBlue.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Text(
              'The answers you provide will help generate your agent\'s rating, and any comments you include may be displayed on your agent\'s profile to help future buyers and sellers make informed decisions.',
              style: TextStyle(
                fontSize: 12.sp,
                color: AppTheme.mediumGray,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentQuestion(BuildContext context) {
    switch (controller.currentStep) {
      case 0:
        return _buildQuestion1(context); // Rebate amount
      case 1:
        return _buildQuestion2(context); // Received expected rebate
      case 2:
        return _buildQuestion3(context); // Rebate application method
      case 3:
        return _buildQuestion4(context); // Signed disclosure
      case 4:
        return _buildQuestion5(context); // Overall satisfaction
      case 5:
        return _buildQuestion6(context); // Rebate ease
      case 6:
        return _buildQuestion7(context); // Recommendation
      case 7:
        return _buildQuestion8(context); // Additional comments
      case 8:
        return _buildQuestion9(context); // Agent rating
      default:
        return const SizedBox.shrink();
    }
  }

  // Question 1: Rebate amount
  Widget _buildQuestion1(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '1. How much was the rebate amount you received?',
          required: true,
        ),
        const SizedBox(height: 16),
        TextField(
          controller: controller.rebateAmountController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
          ],
          decoration: InputDecoration(
            prefixText: '\$ ',
            hintText: 'Enter amount',
            filled: true,
            fillColor: AppTheme.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppTheme.lightGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppTheme.lightGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppTheme.lightGreen,
                width: 2,
              ),
            ),
          ),
          onChanged: (value) {
            final amount = double.tryParse(value);
            if (amount != null && amount > 0) {
              controller.saveRebateAmount();
            }
          },
        ),
        if (controller.rebateAmountSaved) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Rebate amount saved! You can continue with the survey or close it now.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.green.shade700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  // Question 2: Received expected rebate
  Widget _buildQuestion2(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '2. Did you receive the rebate amount you expected?',
          required: true,
        ),
        const SizedBox(height: 16),
        _buildRadioOption(
          context,
          'Yes',
          controller.receivedExpectedRebate == ReceivedExpectedRebate.yes,
          () =>
              controller.setReceivedExpectedRebate(ReceivedExpectedRebate.yes),
        ),
        _buildRadioOption(
          context,
          'No',
          controller.receivedExpectedRebate == ReceivedExpectedRebate.no,
          () => controller.setReceivedExpectedRebate(ReceivedExpectedRebate.no),
        ),
        _buildRadioOption(
          context,
          'Not sure',
          controller.receivedExpectedRebate == ReceivedExpectedRebate.notSure,
          () => controller.setReceivedExpectedRebate(
            ReceivedExpectedRebate.notSure,
          ),
        ),
      ],
    );
  }

  // Question 3: Rebate application method
  Widget _buildQuestion3(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '3. Was the rebate applied as a credit to you at closing?',
          required: true,
        ),
        const SizedBox(height: 16),
        _buildRadioOption(
          context,
          'Yes',
          controller.rebateApplicationMethod == RebateApplicationMethod.credit,
          () => controller.setRebateApplicationMethod(
            RebateApplicationMethod.credit,
          ),
        ),
        _buildRadioOption(
          context,
          'No',
          controller.rebateApplicationMethod == RebateApplicationMethod.no,
          () =>
              controller.setRebateApplicationMethod(RebateApplicationMethod.no),
        ),
        _buildRadioOption(
          context,
          'Other',
          controller.rebateApplicationMethod == RebateApplicationMethod.other,
          () => controller.setRebateApplicationMethod(
            RebateApplicationMethod.other,
          ),
        ),
        if (controller.rebateApplicationMethod ==
            RebateApplicationMethod.other) ...[
          const SizedBox(height: 12),
          TextField(
            controller: controller.rebateApplicationOtherController,
            decoration: InputDecoration(
              hintText: 'Please explain',
              filled: true,
              fillColor: AppTheme.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppTheme.lightGray),
              ),
            ),
            maxLines: 2,
          ),
        ],
      ],
    );
  }

  // Question 4: Signed disclosure
  Widget _buildQuestion4(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '4. Did you and your agent sign the rebate disclosure form?',
          required: true,
        ),
        const SizedBox(height: 16),
        _buildRadioOption(
          context,
          'Yes',
          controller.signedDisclosure == SignedDisclosure.yes,
          () => controller.setSignedDisclosure(SignedDisclosure.yes),
        ),
        _buildRadioOption(
          context,
          'No',
          controller.signedDisclosure == SignedDisclosure.no,
          () => controller.setSignedDisclosure(SignedDisclosure.no),
        ),
        _buildRadioOption(
          context,
          'Not sure',
          controller.signedDisclosure == SignedDisclosure.notSure,
          () => controller.setSignedDisclosure(SignedDisclosure.notSure),
        ),
      ],
    );
  }

  // Question 5: Overall satisfaction (1-5 scale)
  Widget _buildQuestion5(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '5. How satisfied are you with your agent and the rebate process overall?',
          required: true,
        ),
        const SizedBox(height: 8),
        Text(
          '1 = Not satisfied, 5 = Very satisfied',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: AppTheme.mediumGray,
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(height: 16),
        _buildRatingScale(
          1,
          5,
          controller.overallSatisfaction,
          (value) => controller.setOverallSatisfaction(value),
        ),
      ],
    );
  }

  // Question 6: Rebate ease
  Widget _buildQuestion6(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '6. Was receiving your rebate easy?',
          required: true,
        ),
        const SizedBox(height: 16),
        _buildRadioOption(
          context,
          'Very easy',
          controller.rebateEase == RebateEase.veryEasy,
          () => controller.setRebateEase(RebateEase.veryEasy),
        ),
        _buildRadioOption(
          context,
          'Somewhat easy',
          controller.rebateEase == RebateEase.somewhatEasy,
          () => controller.setRebateEase(RebateEase.somewhatEasy),
        ),
        _buildRadioOption(
          context,
          'Neutral',
          controller.rebateEase == RebateEase.neutral,
          () => controller.setRebateEase(RebateEase.neutral),
        ),
        _buildRadioOption(
          context,
          'Difficult',
          controller.rebateEase == RebateEase.difficult,
          () => controller.setRebateEase(RebateEase.difficult),
        ),
      ],
    );
  }

  // Question 7: Recommendation
  Widget _buildQuestion7(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '7. Would you recommend your agent to family and friends?',
          required: true,
        ),
        const SizedBox(height: 16),
        _buildRadioOption(
          context,
          'Definitely',
          controller.recommendationLevel == RecommendationLevel.definitely,
          () =>
              controller.setRecommendationLevel(RecommendationLevel.definitely),
        ),
        _buildRadioOption(
          context,
          'Probably',
          controller.recommendationLevel == RecommendationLevel.probably,
          () => controller.setRecommendationLevel(RecommendationLevel.probably),
        ),
        _buildRadioOption(
          context,
          'Not sure',
          controller.recommendationLevel == RecommendationLevel.notSure,
          () => controller.setRecommendationLevel(RecommendationLevel.notSure),
        ),
        _buildRadioOption(
          context,
          'Probably not',
          controller.recommendationLevel == RecommendationLevel.probablyNot,
          () => controller.setRecommendationLevel(
            RecommendationLevel.probablyNot,
          ),
        ),
        _buildRadioOption(
          context,
          'Definitely not',
          controller.recommendationLevel == RecommendationLevel.definitelyNot,
          () => controller.setRecommendationLevel(
            RecommendationLevel.definitelyNot,
          ),
        ),
      ],
    );
  }

  // Question 8: Additional comments (optional)
  Widget _buildQuestion8(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '8. Is there anything else you\'d like to share about your experience?',
          required: false,
        ),
        const SizedBox(height: 8),
        Text(
          'This is optional. Your comments may be displayed on your agent\'s profile.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: AppTheme.mediumGray,
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: controller.additionalCommentsController,
          decoration: InputDecoration(
            hintText: 'Share your experience...',
            filled: true,
            fillColor: AppTheme.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppTheme.lightGray),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppTheme.lightGray),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppTheme.lightGreen,
                width: 2,
              ),
            ),
          ),
          maxLines: 5,
          maxLength: 500,
        ),
      ],
    );
  }

  // Question 9: Agent rating (1-10 scale)
  Widget _buildQuestion9(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildQuestionTitle(
          context,
          '9. Overall, how would you rate your satisfaction with your agent?',
          required: true,
        ),
        const SizedBox(height: 8),
        Text(
          '1 = Poor, 10 = Excellent',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: AppTheme.mediumGray,
            fontStyle: FontStyle.italic,
          ),
        ),
        const SizedBox(height: 16),
        _buildRatingScale(
          1,
          10,
          controller.agentRating,
          (value) => controller.setAgentRating(value),
        ),
      ],
    );
  }

  Widget _buildQuestionTitle(
    BuildContext context,
    String title, {
    required bool required,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppTheme.black,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        if (required)
          Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              'Required',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.red.shade700,
                fontWeight: FontWeight.w600,
                fontSize: 10,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildRadioOption(
    BuildContext context,
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: selected
              ? AppTheme.lightGreen.withOpacity(0.1)
              : AppTheme.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppTheme.lightGreen : AppTheme.lightGray,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: selected ? AppTheme.lightGreen : AppTheme.mediumGray,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.black,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRatingScale(
    int min,
    int max,
    int? selectedValue,
    Function(int) onSelect,
  ) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(max - min + 1, (index) {
        final value = min + index;
        final selected = selectedValue == value;
        return InkWell(
          onTap: () => onSelect(value),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: selected ? AppTheme.lightGreen : AppTheme.white,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: selected ? AppTheme.lightGreen : AppTheme.lightGray,
                width: selected ? 2 : 1,
              ),
            ),
            child: Center(
              child: Text(
                value.toString(),
                style: TextStyle(
                  color: selected ? AppTheme.white : AppTheme.black,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                  fontSize: 18,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildNavigationButtons(BuildContext context) {
    final canProceed = controller.canProceedFromCurrentStep();
    final isLastStep = controller.currentStep == 8;

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          if (controller.currentStep > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: controller.isLoading
                    ? null
                    : controller.previousStep,
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  side: const BorderSide(color: AppTheme.lightGreen),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Back'),
              ),
            ),
          if (controller.currentStep > 0) const SizedBox(width: 16),
          Expanded(
            flex: 2,
            child: ElevatedButton(
              onPressed: (canProceed && !controller.isLoading)
                  ? (isLastStep ? controller.submitSurvey : controller.nextStep)
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightGreen,
                foregroundColor: AppTheme.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                disabledBackgroundColor: AppTheme.lightGray,
              ),
              child: controller.isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.white,
                        ),
                      ),
                    )
                  : Text(isLastStep ? 'Submit Survey' : 'Next'),
            ),
          ),
        ],
      ),
    );
  }
}
