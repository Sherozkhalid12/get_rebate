import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getrebate/app/models/agent_listing_model.dart';
import 'package:getrebate/app/modules/agent/controllers/agent_controller.dart';

class AddListingController extends GetxController {
  // Form controllers
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final priceController = TextEditingController();
  final addressController = TextEditingController();
  final cityController = TextEditingController();
  final stateController = TextEditingController();
  final zipCodeController = TextEditingController();

  // Observable variables
  final _isLoading = false.obs;
  final _bacPercent = 2.5.obs;
  final _dualAgencyAllowed = false.obs;
  final _isListingAgent = Rxn<bool>(); // Null until answered
  final _selectedPhotos = <String>[].obs;
  final _agreeToLargerRebateForDualAgency = false.obs;
  final _dualAgencyTotalCommissionPercent =
      5.0.obs; // Default 5% total commission
  final _openHouses = <OpenHouseEntry>[].obs;

  // Getters
  bool get isLoading => _isLoading.value;
  double get bacPercent => _bacPercent.value;
  bool get dualAgencyAllowed => _dualAgencyAllowed.value;
  bool? get isListingAgent => _isListingAgent.value;
  List<String> get selectedPhotos => _selectedPhotos;
  bool get agreeToLargerRebateForDualAgency =>
      _agreeToLargerRebateForDualAgency.value;
  double get dualAgencyTotalCommissionPercent =>
      _dualAgencyTotalCommissionPercent.value;
  List<OpenHouseEntry> get openHouses => _openHouses;
  bool get canAddMoreOpenHouses => _openHouses.length < 4;

  @override
  void onInit() {
    super.onInit();
    // Set default values
    _bacPercent.value = 2.5;
    _dualAgencyAllowed.value = false;
  }

  void updateBacPercent(double value) {
    _bacPercent.value = value;
  }

  void toggleDualAgency() {
    _dualAgencyAllowed.value = !_dualAgencyAllowed.value;
    // Reset rebate agreement when dual agency is toggled off
    if (!_dualAgencyAllowed.value) {
      _agreeToLargerRebateForDualAgency.value = false;
    }
  }

  void toggleAgreeToLargerRebate() {
    _agreeToLargerRebateForDualAgency.value =
        !_agreeToLargerRebateForDualAgency.value;
  }

  void updateDualAgencyTotalCommission(double value) {
    _dualAgencyTotalCommissionPercent.value = value;
  }

  void setIsListingAgent(bool value) {
    _isListingAgent.value = value;

    // If not listing agent, disable dual agency
    // (can't offer dual agency on someone else's listing)
    if (!value) {
      _dualAgencyAllowed.value = false;
    }
  }

  void addPhoto(String photoUrl) {
    if (_selectedPhotos.length < 10) {
      // Max 10 photos
      _selectedPhotos.add(photoUrl);
    } else {
      Get.snackbar('Limit Reached', 'You can add up to 10 photos');
    }
  }

  void removePhoto(int index) {
    _selectedPhotos.removeAt(index);
  }

  void addOpenHouse() {
    if (_openHouses.length >= 4) {
      Get.snackbar('Limit Reached', 'You can add up to 4 open houses');
      return;
    }
    _openHouses.add(OpenHouseEntry());
  }

  void removeOpenHouse(int index) {
    if (index >= 0 && index < _openHouses.length) {
      _openHouses.removeAt(index);
    }
  }

  void updateOpenHouseDate(int index, DateTime date) {
    if (index >= 0 && index < _openHouses.length) {
      _openHouses[index].date = date;
    }
  }

  void updateOpenHouseStartTime(int index, TimeOfDay time) {
    if (index >= 0 && index < _openHouses.length) {
      _openHouses[index].startTime = time;
    }
  }

  void updateOpenHouseEndTime(int index, TimeOfDay time) {
    if (index >= 0 && index < _openHouses.length) {
      _openHouses[index].endTime = time;
    }
  }

  void updateOpenHouseNotes(int index, String notes) {
    if (index >= 0 && index < _openHouses.length) {
      _openHouses[index].notes = notes;
    }
  }

  Future<void> submitListing() async {
    if (!_validateForm()) return;

    try {
      _isLoading.value = true;

      // Create listing model
      final listing = AgentListingModel(
        id: 'listing_${DateTime.now().millisecondsSinceEpoch}',
        agentId: 'agent_1', // In real app, get from auth
        title: titleController.text.trim(),
        description: descriptionController.text.trim(),
        priceCents: (double.parse(priceController.text) * 100).round(),
        address: addressController.text.trim(),
        city: cityController.text.trim(),
        state: stateController.text.trim(),
        zipCode: zipCodeController.text.trim(),
        photoUrls: _selectedPhotos,
        bacPercent: _bacPercent.value,
        dualAgencyAllowed: _dualAgencyAllowed.value,
        dualAgencyCommissionPercent:
            _dualAgencyAllowed.value && _agreeToLargerRebateForDualAgency.value
            ? _dualAgencyTotalCommissionPercent.value
            : null,
        isListingAgent: _isListingAgent.value ?? false,
        isActive: true,
        isApproved: false,
        createdAt: DateTime.now(),
      );

      // Get agent controller and add listing
      final agentController = Get.find<AgentController>();
      await agentController.addListing(listing);

      // Navigate back
      Get.back();
    } catch (e) {
      Get.snackbar('Error', 'Failed to add listing: ${e.toString()}');
    } finally {
      _isLoading.value = false;
    }
  }

  bool _validateForm() {
    if (titleController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a title');
      return false;
    }

    if (descriptionController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a description');
      return false;
    }

    if (priceController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a price');
      return false;
    }

    final price = double.tryParse(priceController.text);
    if (price == null || price <= 0) {
      Get.snackbar('Error', 'Please enter a valid price');
      return false;
    }

    if (addressController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter an address');
      return false;
    }

    if (cityController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a city');
      return false;
    }

    if (stateController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a state');
      return false;
    }

    if (zipCodeController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter a ZIP code');
      return false;
    }

    // CRITICAL: Verify listing agent status
    if (_isListingAgent.value == null) {
      Get.snackbar(
        'Error',
        'Please confirm if you are the listing agent for this property',
        duration: const Duration(seconds: 4),
      );
      return false;
    }

    // Warning if not the listing agent
    if (_isListingAgent.value == false) {
      Get.snackbar(
        'Warning',
        'You indicated you are NOT the listing agent. Dual agency will not be available, and commission structure may differ.',
        duration: const Duration(seconds: 5),
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
    }

    return true;
  }

  @override
  void onClose() {
    titleController.dispose();
    descriptionController.dispose();
    priceController.dispose();
    addressController.dispose();
    cityController.dispose();
    stateController.dispose();
    zipCodeController.dispose();
    super.onClose();
  }
}

// Helper class for managing open house entries during form filling
class OpenHouseEntry {
  DateTime date;
  TimeOfDay startTime;
  TimeOfDay endTime;
  String notes;

  OpenHouseEntry({
    DateTime? date,
    TimeOfDay? startTime,
    TimeOfDay? endTime,
    String? notes,
  }) : date = date ?? DateTime.now(),
       startTime = startTime ?? const TimeOfDay(hour: 10, minute: 0),
       endTime = endTime ?? const TimeOfDay(hour: 14, minute: 0),
       notes = notes ?? '';
}
