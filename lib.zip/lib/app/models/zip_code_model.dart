class ZipCodeModel {
  final String zipCode;
  final String state;
  final int population;
  final String? claimedByAgent;
  final String? claimedByLoanOfficer;
  final DateTime? claimedAt;
  final double price;
  final bool isAvailable;
  final DateTime createdAt;
  final DateTime? lastSearchedAt;
  final int searchCount;

  ZipCodeModel({
    required this.zipCode,
    required this.state,
    required this.population,
    this.claimedByAgent,
    this.claimedByLoanOfficer,
    this.claimedAt,
    required this.price,
    this.isAvailable = true,
    required this.createdAt,
    this.lastSearchedAt,
    this.searchCount = 0,
  });

  factory ZipCodeModel.fromJson(Map<String, dynamic> json) {
    return ZipCodeModel(
      zipCode: json['zipCode'] ?? '',
      state: json['state'] ?? '',
      population: json['population'] ?? 0,
      claimedByAgent: json['claimedByAgent'],
      claimedByLoanOfficer: json['claimedByLoanOfficer'],
      claimedAt: json['claimedAt'] != null
          ? DateTime.parse(json['claimedAt'])
          : null,
      price: (json['price'] ?? 0.0).toDouble(),
      isAvailable: json['isAvailable'] ?? true,
      createdAt: DateTime.parse(
        json['createdAt'] ?? DateTime.now().toIso8601String(),
      ),
      lastSearchedAt: json['lastSearchedAt'] != null
          ? DateTime.parse(json['lastSearchedAt'])
          : null,
      searchCount: json['searchCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'zipCode': zipCode,
      'state': state,
      'population': population,
      'claimedByAgent': claimedByAgent,
      'claimedByLoanOfficer': claimedByLoanOfficer,
      'claimedAt': claimedAt?.toIso8601String(),
      'price': price,
      'isAvailable': isAvailable,
      'createdAt': createdAt.toIso8601String(),
      'lastSearchedAt': lastSearchedAt?.toIso8601String(),
      'searchCount': searchCount,
    };
  }

  ZipCodeModel copyWith({
    String? zipCode,
    String? state,
    int? population,
    String? claimedByAgent,
    String? claimedByLoanOfficer,
    DateTime? claimedAt,
    double? price,
    bool? isAvailable,
    DateTime? createdAt,
    DateTime? lastSearchedAt,
    int? searchCount,
  }) {
    return ZipCodeModel(
      zipCode: zipCode ?? this.zipCode,
      state: state ?? this.state,
      population: population ?? this.population,
      claimedByAgent: claimedByAgent ?? this.claimedByAgent,
      claimedByLoanOfficer: claimedByLoanOfficer ?? this.claimedByLoanOfficer,
      claimedAt: claimedAt ?? this.claimedAt,
      price: price ?? this.price,
      isAvailable: isAvailable ?? this.isAvailable,
      createdAt: createdAt ?? this.createdAt,
      lastSearchedAt: lastSearchedAt ?? this.lastSearchedAt,
      searchCount: searchCount ?? this.searchCount,
    );
  }

  bool get isClaimed => claimedByAgent != null || claimedByLoanOfficer != null;

  String get tier {
    if (population < 1000) return 'Tier 1';
    if (population < 5000) return 'Tier 2';
    if (population < 10000) return 'Tier 3';
    if (population < 20000) return 'Tier 4';
    return 'Tier 5';
  }
}
