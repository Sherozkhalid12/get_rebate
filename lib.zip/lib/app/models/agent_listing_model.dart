class AgentListingModel {
  final String id;
  final String agentId;
  final String title;
  final String description;
  final int priceCents;
  final String address;
  final String city;
  final String state;
  final String zipCode;
  final List<String> photoUrls;
  final double bacPercent;
  final bool dualAgencyAllowed;
  final double?
  dualAgencyCommissionPercent; // Total commission % for dual agency (e.g., 4.0, 5.0, 6.0)
  final bool
  isListingAgent; // Whether the submitting agent is the actual listing agent
  final bool isActive;
  final bool isApproved;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? approvedAt;
  final int searchCount;
  final int viewCount;
  final int contactCount;
  final String? rejectionReason;

  AgentListingModel({
    required this.id,
    required this.agentId,
    required this.title,
    required this.description,
    required this.priceCents,
    required this.address,
    required this.city,
    required this.state,
    required this.zipCode,
    this.photoUrls = const [],
    required this.bacPercent,
    required this.dualAgencyAllowed,
    this.dualAgencyCommissionPercent,
    this.isListingAgent = true, // Default to true for backward compatibility
    this.isActive = true,
    this.isApproved = false,
    required this.createdAt,
    this.updatedAt,
    this.approvedAt,
    this.searchCount = 0,
    this.viewCount = 0,
    this.contactCount = 0,
    this.rejectionReason,
  });

  factory AgentListingModel.fromJson(Map<String, dynamic> json) {
    return AgentListingModel(
      id: json['id'] ?? '',
      agentId: json['agentId'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      priceCents: json['priceCents'] ?? 0,
      address: json['address'] ?? '',
      city: json['city'] ?? '',
      state: json['state'] ?? '',
      zipCode: json['zipCode'] ?? '',
      photoUrls: List<String>.from(json['photoUrls'] ?? []),
      bacPercent: (json['bacPercent'] ?? 0.0).toDouble(),
      dualAgencyAllowed: json['dualAgencyAllowed'] ?? false,
      dualAgencyCommissionPercent: json['dualAgencyCommissionPercent'] != null
          ? (json['dualAgencyCommissionPercent'] as num).toDouble()
          : null,
      isListingAgent: json['isListingAgent'] ?? true,
      isActive: json['isActive'] ?? true,
      isApproved: json['isApproved'] ?? false,
      createdAt: DateTime.parse(
        json['createdAt'] ?? DateTime.now().toIso8601String(),
      ),
      updatedAt: json['updatedAt'] != null
          ? DateTime.parse(json['updatedAt'])
          : null,
      approvedAt: json['approvedAt'] != null
          ? DateTime.parse(json['approvedAt'])
          : null,
      searchCount: json['searchCount'] ?? 0,
      viewCount: json['viewCount'] ?? 0,
      contactCount: json['contactCount'] ?? 0,
      rejectionReason: json['rejectionReason'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'agentId': agentId,
      'title': title,
      'description': description,
      'priceCents': priceCents,
      'address': address,
      'city': city,
      'state': state,
      'zipCode': zipCode,
      'photoUrls': photoUrls,
      'bacPercent': bacPercent,
      'dualAgencyAllowed': dualAgencyAllowed,
      'dualAgencyCommissionPercent': dualAgencyCommissionPercent,
      'isListingAgent': isListingAgent,
      'isActive': isActive,
      'isApproved': isApproved,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'approvedAt': approvedAt?.toIso8601String(),
      'searchCount': searchCount,
      'viewCount': viewCount,
      'contactCount': contactCount,
      'rejectionReason': rejectionReason,
    };
  }

  AgentListingModel copyWith({
    String? id,
    String? agentId,
    String? title,
    String? description,
    int? priceCents,
    String? address,
    String? city,
    String? state,
    String? zipCode,
    List<String>? photoUrls,
    double? bacPercent,
    bool? dualAgencyAllowed,
    double? dualAgencyCommissionPercent,
    bool? isListingAgent,
    bool? isActive,
    bool? isApproved,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? approvedAt,
    int? searchCount,
    int? viewCount,
    int? contactCount,
    String? rejectionReason,
  }) {
    return AgentListingModel(
      id: id ?? this.id,
      agentId: agentId ?? this.agentId,
      title: title ?? this.title,
      description: description ?? this.description,
      priceCents: priceCents ?? this.priceCents,
      address: address ?? this.address,
      city: city ?? this.city,
      state: state ?? this.state,
      zipCode: zipCode ?? this.zipCode,
      photoUrls: photoUrls ?? this.photoUrls,
      bacPercent: bacPercent ?? this.bacPercent,
      dualAgencyAllowed: dualAgencyAllowed ?? this.dualAgencyAllowed,
      dualAgencyCommissionPercent:
          dualAgencyCommissionPercent ?? this.dualAgencyCommissionPercent,
      isListingAgent: isListingAgent ?? this.isListingAgent,
      isActive: isActive ?? this.isActive,
      isApproved: isApproved ?? this.isApproved,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      approvedAt: approvedAt ?? this.approvedAt,
      searchCount: searchCount ?? this.searchCount,
      viewCount: viewCount ?? this.viewCount,
      contactCount: contactCount ?? this.contactCount,
      rejectionReason: rejectionReason ?? this.rejectionReason,
    );
  }

  String get fullAddress => '$address, $city, $state $zipCode';

  String get formattedPrice {
    final dollars = priceCents ~/ 100;
    final cents = priceCents % 100;
    final formattedDollars = dollars.toString().replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]},',
    );
    return '\$$formattedDollars.${cents.toString().padLeft(2, '0')}';
  }

  String get status {
    if (!isActive) return 'Inactive';
    if (!isApproved) return 'Pending Approval';
    if (rejectionReason != null) return 'Rejected';
    return 'Active';
  }
}
